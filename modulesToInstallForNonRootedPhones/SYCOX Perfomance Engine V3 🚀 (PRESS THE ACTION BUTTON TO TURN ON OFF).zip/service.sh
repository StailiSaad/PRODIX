#!/system/bin/sh
run() {
mode=$(getprop debug.sycox.perfomance.engine)

[ -z "$mode" ] && mode=off

if [ "$mode" = off ]; then

memory=$(cat /proc/meminfo)
uptime=$(cat /proc/uptime | awk '{print int($1)}')

# Fix CPU freq
cpu_freq_raw=$(cat /sys/devices/system/cpu/cpufreq/*/cpuinfo_max_freq 2>/dev/null | tail -n1)
cpu_freq=$(awk -v freq="$cpu_freq_raw" 'BEGIN { printf("%.3f", freq/1000000) }')

# Auto detect working thermal zone
temp=""
for zone in /sys/class/thermal/thermal_zone*/temp; do
  val=$(cat "$zone" 2>/dev/null)
  if [ "$val" != "" ] && [ "$val" -gt 0 ] && [ "$val" -lt 200000 ]; then
    temp=$val
    break
  fi
done

# Convert to °C or set unknown
if [ "$temp" != "" ]; then
  temp_c=$(awk -v t="$temp" 'BEGIN { printf("%d", t/1000) }')
else
  temp_c="Unknown"
fi

echo "┌────────────────────────────────────────────────────────┐"
echo "│            📱 DEVICE & HARDWARE INFORMATION            │"
echo "├────────────────────────────────────────────────────────┤"
echo "│ 🧩 OS         : Android $(getprop ro.build.version.release)"
echo "│ 📱 Model      : $(getprop ro.product.manufacturer) $(getprop ro.product.model)"
echo "│ 🐧 Kernel     : $(uname -r | cut -f1,2,3 -d-)"
echo "│ ⏱️ Uptime     : $((uptime/3600)) hour, $((uptime%3600/60)) mins"
echo "│ 📦 Packages   : $(cmd package list packages -s --user 0 | wc -l) (sys), $(cmd package list packages -3 --user 0 | wc -l) (trd)"
echo "│ 🖥️ Resolution : $(wm size | cut -d: -f2)"
echo "│ 🎨 Theme      : $(getprop ro.build.fingerprint | tr '/' '\n' | grep user | cut -f1 -d:)"
echo "│ 💻 Terminal   : $(cmd activity stack list | grep 0,0.*visible=true | tr -d ' ' | cut -f1 -d/ | cut -f2 -d:)"
echo "│ ⚙️ CPU        : $(getprop ro.soc.manufacturer) $(getprop ro.soc.model) ($(grep -c proc /proc/cpuinfo)) @ ${cpu_freq} GHz"
echo "│ 🎮 GPU        : $(dumpsys SurfaceFlinger | grep GLES: | cut -f2 -d,)"
echo "│ 🧠 Memory     : $((($(echo \"$memory\" | grep MemTotal | awk '{print $2}')-$(echo \"$memory\" | grep MemAvailable | awk '{print $2}'))/1024))MiB / $(($(echo \"$memory\" | grep MemTotal | awk '{print $2}')/1024))MiB"
echo "│ 🌡️ Thermal    : ${temp_c}°C"
echo "│ 🧱 Build      : $(getprop ro.build.display.id)"
echo "│ 🔑 Root       : $(if [ $(id -u) -eq 0 ]; then echo Yes; else echo No; fi)"
echo "│ 🛡️ SELinux    : $(getenforce)"
echo "└────────────────────────────────────────────────────────┘"

echo "█▓▒▒░░░WELCOME TO INSTALLATION░░░▒▒▓█"
echo ""
sleep 0.5
echo ""
echo " 
██████╗░███████╗███╗░░██╗███╗░░██╗
██╔══██╗██╔════╝████╗░██║████╗░██║
██████╔╝█████╗░░██╔██╗██║██╔██╗██║
██╔══██╗██╔══╝░░██║╚████║██║╚████║
██║░░██║███████╗██║░╚███║██║░╚███║
╚═╝░░╚═╝╚══════╝╚═╝░░╚══╝╚═╝░░╚══╝ "

    # 1. Ambil data SEKALI saja biar script INSTAN
    MY_FPS=$(dumpsys display | grep -Eo 'fps=[^.]+' | cut -f2 -d= | sort -n | uniq | tail -n1)
    MY_RES=$(wm size | awk '{print $3}')
    MY_WIDTH=$(echo $MY_RES | cut -d'x' -f1)
    MY_HEIGHT=$(echo $MY_RES | cut -d'x' -f2)

    echo "⚙️ Lock: $MY_WIDTH x $MY_HEIGHT @ ${MY_FPS}Hz"

    # 2. Kunci Layar
    cmd display set-match-content-frame-rate-pref 2
    cmd display set-user-preferred-display-mode $MY_WIDTH $MY_HEIGHT $MY_FPS 0

    # 3. Deteksi Mediatek
    chipset=$(getprop ro.soc.manufacturer | tr "[:upper:]" "[:lower:]")
    if echo "$chipset" | grep -qi "mediatek"; then
        setprop debug.mediatek.high_frame_rate_multiple_display_mode 0
        setprop debug.mediatek.high_frame_rate_sf_set_big_core_fps_threshold $MY_FPS
    fi

    # 4. Property Penting Saja
    setprop debug.sf.default_refresh_rate $MY_FPS
    setprop debug.sf.frame_rate_multiple_threshold $MY_FPS
    
    # Mengunci Settingan Android System
    settings put system peak_refresh_rate $MY_FPS
    settings put system min_refresh_rate $MY_FPS
    settings put system user_refresh_rate $MY_FPS
    
    # ==========================================
    # 🔋 POWER MANAGEMENT & SYSTEM OPTIMIZATION
    # ==========================================
    
    # 1. CORE POWER COMMANDS (Wajib buat Android modern)
    # Mematikan fitur hemat daya adaptif yang suka melimit CPU
    cmd power set-adaptive-power-saver-enabled false > /dev/null 2>&1
    # Memaksa mode performa tetap (High Performance Mode)
    cmd power set-fixed-performance-mode-enabled true > /dev/null 2>&1

    # 2. SYSTEM & STATS (Mengurangi beban background)
    cmd looper_stats disable
    setprop sys.uidcpupower 0 > /dev/null 2>&1
    settings put --user 0 global sys_uidcpupower 0
    settings put --user 0 global looper_stats enabled=false,sampling_interval=0
    
    # 3. BATTERY SAVER KILLER (Mematikan semua pemicu hemat baterai)
    settings put --user 0 system background_power_saving_enable 0
    settings put --user 0 global adaptive_battery_management_enabled 0
    
    # Mematikan "Battery Tips" (Saran hemat baterai dari Android)
    settings put --user 0 global battery_tip_constants battery_tip_enabled=false,summary_enabled=false,battery_saver_tip_enabled=false,high_usage_enabled=false,high_usage_app_count=0,high_usage_period_ms=0,high_usage_battery_draining=0,app_restriction_enabled=false,reduced_battery_enabled=false,reduced_battery_percent=0,low_battery_enabled=false,low_battery_hour=0,animation_disabled=true
    
    # Reset & Disable Konstanta Hemat Baterai
    settings put global battery_saver_adaptive_device_specific_constants ""
    settings put global battery_saver_adaptive_constants ""
    settings put --user 0 global battery_saver_constants advertise_is_enabled=false,datasaver_disabled=false,enable_night_mode=false,launch_boost_disabled=false,vibration_disabled=false,soundtrigger_disabled=false,fullbackup_deferred=true,keyvaluebackup_deferred=true,firewall_disabled=true,gps_mode=2,adjust_brightness_disabled=false,adjust_brightness_factor=0.5,force_all_apps_standby=0,force_background_check=false,optional_sensors_disabled=true,aod_disabled=true,quick_doze_enabled=false
    
    # 4. DOZE & IDLE TWEAK (Mencegah HP 'Tidur' saat Game)
    # Memperlama waktu sebelum HP masuk mode idle/doze
    settings put --user 0 global device_idle_constants inactive_to=600000,sensing_to=900000,motion_inactive_to=600000,idle_after_inactive_to=1800000,idle_pending_to=600000,max_idle_pending_to=1200000,idle_pending_factor=2.0,quick_doze_delay_to=1200000,idle_to=3600000,max_idle_to=7200000,idle_factor=3.0,min_time_to_alarm=300000,max_temp_app_whitelist_duration=900000,notification_whitelist_duration=900000
    
    # 5. ACTIVITY MANAGER & RAM (Manajemen Proses)
    # Memaksa GPU Rendering untuk UI (Sesuai request kamu di blok ini)
    settings put --user 0 global force_gpu_rendering 1
    
    # Mengurangi logging statistik baterai (Hemat CPU)
    settings put --user 0 global battery_stats_constants track_cpu_times_by_proc_state=false,track_cpu_active_cluster_time=false,read_binary_cpu_time=true,proc_state_cpu_times_read_delay_ms=5000,external_stats_collection_rate_limit_ms=600000,battery_level_collection_delay_ms=60000,max_history_files=16,max_history_buffer_kb=1024,battery_charged_delay_ms=60000
    
    # Tweak Activity Manager (Multitasking & Background)
    settings put --user 0 global app_ops_constants top_state_settle_time=30000,fg_service_state_settle_time=30000,bg_state_settle_time=60000
    settings put --user 0 global activity_manager_constants max_cached_processes=2147483647,background_settle_time=0,fgservice_min_shown_time=0,fgservice_min_report_time=0,fgservice_screen_on_before_time=0,fgservice_screen_on_after_time=0,gc_timeout=0,gc_min_interval=0,full_pss_min_interval=0,full_pss_lowered_interval=0,power_check_max_cpu_1=100,power_check_max_cpu_2=100,power_check_max_cpu_3=100,power_check_max_cpu_4=100,service_usage_interaction_time=0,usage_stats_interaction_interval=0,service_restart_duration=0,service_reset_run_duration=0,service_restart_duration_factor=0,service_min_restart_time_between=0,service_max_inactivity=0,service_bg_start_timeout=0,service_bg_activity_start_timeout=0,process_start_async=true,content_provider_retain_time=0,CUR_MAX_CACHED_PROCESSES=0,CUR_MAX_EMPTY_PROCESSES=0,CUR_TRIM_EMPTY_PROCESSES=0,CUR_TRIM_CACHED_PROCESSES=0
    
    # 6. STANDBY & RESTRICTION CLEANUP
    settings put --user 0 global power_manager_constants no_cached_wake_locks=1
    settings put --user 0 global kernel_cpu_thread_reader num_buckets=1,collected_uids=,minimum_total_cpu_usage_millis=60000
    settings put --user 0 global forced_app_standby_for_small_battery_enabled 0
    settings put --user 0 global forced_app_standby_enabled 0
    settings put --user 0 global app_auto_restriction_enabled 0
    settings put --user 0 global app_standby_enabled 0
    settings put --user 0 global app_idle_constants parole_interval=1800000,parole_window=600000,parole_duration=600000,screen_thresholds=0/0/900000/1800000,elapsed_thresholds=0/0/1800000/3600000,strong_usage_duration=600000,notification_seen_duration=600000,system_update_usage_duration=900000,prediction_timeout=600000,sync_adapter_duration=300000,exempted_sync_duration=600000,system_interaction_duration=300000,initial_foreground_service_start_duration=600000,stable_charging_threshold=300000,idle_duration=0,idle_duration2=0,wallclock_threshold=0
    settings put --user 0 global display_panel_lpm false
    settings put --user 0 global dynamic_power_savings 0
    settings put --user 0 global dynamic_power_savings_disable_threshold 0
    settings put --user 0 global dynamic_power_savings_enabled 0
    
    # 7. LOW POWER MODE KILLER (Final Check)
    settings put --user 0 global low_power 0
    settings put --user 0 global low_power_sticky 0
    settings put --user 0 global low_power_sticky_auto_disable_level 0
    settings put --user 0 global low_power_sticky_auto_disable_enabled 0
    settings put --user 0 global low_power_trigger_level 0
    settings put --user 0 global low_power_trigger_level_max 1
    settings put --user 0 global low_power_mode_suggestion_params trigger_level=1,dismiss_duration=86400000
    settings put --user 0 global automatic_power_save_mode 0
    settings put --user 0 secure sysui_tuner_version 4
    

# ==========================================
# GAMING SCRIPT V6
# ==========================================

# 1. PERSIAPAN DATA
# ------------------------------------------
ANDROID_VER=$(getprop ro.build.version.release | cut -d'.' -f1)
MAX_FPS=$(dumpsys display | grep -Eo 'fps=[0-9]+' | sort -n | tail -n1 | cut -d= -f2)
if [ -z "$MAX_FPS" ]; then MAX_FPS=60; fi
MAX_FPS=${MAX_FPS%.*}

# === SETTINGAN ===
# Boost I/O
BOOST_VAL="1073741824"
# Downscale (0.9 = Tajam & Ringan)
DS_FACTOR="0.9"

echo " "
echo "╔═══════════════════════════════════════╗"
echo "║    🚀 PERFORMANCE MODE (ACCUMULATED)  ║"
echo "╠═══════════════════════════════════════╣"
echo "║ 📱 Android Ver  : $ANDROID_VER                  ║"
echo "║ ⚡ Target FPS   : ${MAX_FPS}Hz                ║"
echo "║ 📉 Downscale    : ${DS_FACTOR}x                 ║"
echo "╚═══════════════════════════════════════╝"
echo " "

# 2. SCANNING GAME
# ------------------------------------------
GAME_LIST=$(dumpsys game | grep -o "$(cmd package list packages --user 0 | cut -f2 -d:)")
if [ -z "$GAME_LIST" ]; then
    # Fallback jika dumpsys kosong
    GAME_LIST=$(cmd package list packages -3 | cut -f2 -d :)
fi

# Variabel Penampung List Driver (Dikosongkan dulu)
LIST_GAME_DRIVER=""
CNT=0

echo "⚙️ Memulai Optimasi..."

# 3. LOOP EKSEKUSI
# ------------------------------------------
for app in $GAME_LIST; do

    # Filter System Apps
    if [ "$app" = "com.frb.axmanager" ]; then continue; fi
    if [ "$app" = "android" ]; then continue; fi
    if [ -z "$app" ]; then continue; fi

    # Hitung Counter
    CNT=$((CNT + 1))
    
    # === 🎲 RANDOM EMOJI (LOGIC) ===
    # Menggunakan modulus matematika untuk rotasi 4 ikon
    case $((CNT % 4)) in
        0) ICON="🚀" ;;
        1) ICON="🎮" ;;
        2) ICON="🔥" ;;
        3) ICON="⚔️" ;;
    esac

    echo "   $ICON [BOOST] $app"

    # === 🔑 LOGIKA PENGGABUNGAN LIST DRIVER (TWEAK LAMA) ===
    # Jika list masih kosong, isi langsung.
    # Jika sudah ada isinya, tambahkan koma (,) lalu nama app baru.
    if [ -z "$LIST_GAME_DRIVER" ]; then 
        LIST_GAME_DRIVER="$app" 
    else 
        LIST_GAME_DRIVER="${LIST_GAME_DRIVER},${app}" 
    fi

    # Reset Config
    device_config delete game_overlay "$app" > /dev/null 2>&1

    # === KONFIGURASI PERFORMA (Mode 2 Only) ===
    if [ "$ANDROID_VER" -ge 14 ]; then
        # String Config A14+
        CONFIG_STRING="mode=2,fps=$MAX_FPS,downscaleFactor=$DS_FACTOR,loadingBoost=$BOOST_VAL,downscale=$DS_FACTOR"
        
        device_config put game_overlay "$app" "$CONFIG_STRING"
        cmd game mode performance "$app" > /dev/null 2>&1
        cmd game set --mode 2 --fps $MAX_FPS --downscale $DS_FACTOR --user 0 "$app" > /dev/null 2>&1

    elif [ "$ANDROID_VER" -eq 13 ]; then
        CONFIG_STRING="mode=2,fps=$MAX_FPS,downscaleFactor=$DS_FACTOR,loadingBoost=$BOOST_VAL"
        
        device_config put game_overlay "$app" "$CONFIG_STRING"
        cmd game mode performance "$app" > /dev/null 2>&1
        cmd game set --mode 2 --fps $MAX_FPS --downscale $DS_FACTOR --user 0 "$app" > /dev/null 2>&1

    else
        CONFIG_STRING="mode=2,fps=$MAX_FPS,loadingBoost=$BOOST_VAL"
        device_config put game_overlay "$app" "$CONFIG_STRING"
        cmd game mode performance "$app" > /dev/null 2>&1
        if [ "$DS_FACTOR" != "disable" ]; then
            cmd game downscale "$DS_FACTOR" "$app" > /dev/null 2>&1
        fi
    fi

done

# 4. TERAPKAN GAME DRIVER MASSAL
# ------------------------------------------
echo " "
echo "🎨 Menerapkan Driver Grafis..."

if [ ! -z "$LIST_GAME_DRIVER" ]; then
    # Masukkan SELURUH list game yang sudah digabung koma tadi
    settings put global game_driver_opt_in_apps "$LIST_GAME_DRIVER"
    settings put global game_driver_prerelease_opt_in_apps "$LIST_GAME_DRIVER"
    
    # Note: Kita set 'all_apps 0' supaya HANYA list di atas yang kena driver.
    # Kalau 'all_apps 1', aplikasi bank/sosmed ikut kena dan bisa ngebug.
    settings put global game_driver_all_apps 0
    
    echo "   ✅ Driver Game aktif untuk: $CNT Aplikasi"
else
    echo "   ⚠️ Tidak ada game terdeteksi untuk driver."
fi

# Cleanup
cmd looper_stats disable > /dev/null 2>&1

echo " "
echo "✅ SELESAI! $CNT Game telah dioptimalkan (Mode 2 + Driver)."


{
# =========================================================
#  🔥 SYCOX Perfomance Engine - COMPLETE EDITION
# =========================================================

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║      🚀 SYCOX PERFORMANCE ENGINE V3 VVIP    ║"
echo "║      🔰 MODE: SMART BOOST | 📱 DEVICE: $BRAND    ║"
echo "╚══════════════════════════════════════════════╝"
echo ""
sleep 1

# [10%] INITIALIZING
echo "⚙️  [||........] 10%  >> 🔄 Mounting Core System..."
sleep 0.5

    # =========================================================
    # 1. CORE VISUAL, TOUCH & SURFACE FLINGER (FINAL MIX)
    # =========================================================
    
    # --- Surface Flinger (Komposisi Layar) ---
    setprop debug.sf.hw 1
    
    # Multithreading: Membagi beban kerja UI ke beberapa core CPU (PENTING buat HP Kentang)
    setprop debug.sf.multithreaded_present true
    
    # --- IDLE TIMER & REFRESH RATE LOCK ---
    # Mencegah layar menurunkan Hz saat jari diam sebentar (Anti Stutter)
    setprop debug.sf.set_touch_timer_ms 0
    setprop debug.sf.default_idle_timer_ms 0
    setprop debug.sf.default_touch_timer_ms 0
    setprop debug.sf.set_idle_timer_ms 0
    
    # Matikan overlay update yang tidak perlu
    setprop debug.sf.kernel_idle_timer_update_overlay false

    # --- TOUCH SENSITIVITY (RESPONSIVITAS) ---
    # Mengaktifkan mode sensitivitas tinggi (mirip Glove Mode)
    setprop debug.touch_sensitivity_mode 1
    
    # Mengurangi latensi/jeda sentuhan (Skala 0.1 = Sangat agresif)
    setprop debug.touchscreen.latency.scale 0.1
    
    # Smart Touch (Jika didukung Vendor/Mediatek)
    setprop debug.vendor.perf.smart_touch 1
    setprop debug.vendor.perf.smart_touch.move 1
    setprop debug.vendor.perf.smart_touch.trace 1

    # --- HWUI & RENDERING (Grafis Game) ---
    setprop debug.egl.hw 1
    
    # Optimasi Buffer (Biar transisi smooth)
    setprop debug.hwui.use_gpu_pixel_buffers true
    setprop debug.hwui.use_buffer_age true
    
    # Efisiensi: Hanya render yang berubah (Hemat GPU)
    setprop debug.hwui.use_partial_updates true
    setprop debug.hwui.enable_partial_updates true
    setprop debug.hwui.skip_empty_damage true
    
    # Bersih-bersih fitur debugging
    setprop debug.hwui.render_dirty_regions false
    setprop debug.hwui.show_dirty_regions false
    setprop debug.sf.disable_blurs 1
    setprop debug.sf.use_background_blur 0
    
    
# [30%] TOUCH TUNING
echo "👆 [||||......] 30%  >> 🎯 Calibrating Touch Matrix..."
sleep 0.5

# =========================================================
# 2. TOUCH RESPONSIVENESS (SAFE MODE)
# =========================================================
# Sesuai request: Matikan TouchBoost biar gak panas di Entry Level
setprop sys.touchboost.enabled 0
setprop sys.input.boost.enabled true

# Gunakan optimasi software saja (Anti-Delay)
setprop debug.touch_sensitivity_mode 1
setprop debug.touchscreen.latency.scale 0.1
setprop debug.input.avg_event_time 0
setprop debug.tracing.block_touch_buffer 1
setprop persist.sys.touch.tuning true
setprop persist.sys.enable_sched_touchdown true
setprop debug.vendor.perf.smart_touch 1

# =========================================================
# 3. PERFORMANCE TUNING & BATTERY
# =========================================================
# Tuning Dasar
setprop debug.perf.tuning 1
setprop debug.performance.tuning 1
setprop debug.kill_allocating_task 0

# Battery Restriction Removal (Full)
settings put --user 0 global adaptive_battery_management_enabled 0
settings put --user 0 system background_power_saving_enable 0
cmd power set-adaptive-power-saver-enabled false
setprop debug.power_management_mode pref_max

# Disable CPU Limits
setprop persist.sys.cpulimit.enable false
setprop debug.dev.disable_sched_boost false

# Kurangi beban monitoring sistem (Looper Stats)
# Ini mematikan pencatatan statistik background yang memakan siklus CPU
cmd looper_stats disable
settings put --user 0 global looper_stats enabled=false,sampling_interval=0

# Percepat waktu perpindahan aplikasi (App Switching)
settings put --user 0 global app_ops_constants top_state_settle_time=1000,fg_service_state_settle_time=1000,bg_state_settle_time=1000


# =========================================================
# 4. SMART CPU TOPOLOGY (UNIVERSAL AI DETECT)
#    Support: Entry Level - Mid End | Android 10 - 15
# =========================================================
# [60%] CPU INTELLIGENCE
echo "🧠 [||||||....] 60%  >> 🧬 Analyzing Silicon Topology..."
sleep 0.5

# --- A. HARDWARE INTELLIGENCE ---
# 1. Deteksi RAM (GB)
TOTAL_RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
TOTAL_RAM_GB=$((TOTAL_RAM_KB / 1024 / 1024))

# 2. Deteksi Struktur Core (Helio G-Series Fix)
CPU_COUNT=$(grep -c ^processor /proc/cpuinfo)
FREQ_CORE0=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null || echo 1000)
FREQ_CORE4=$(cat /sys/devices/system/cpu/cpu4/cpufreq/cpuinfo_max_freq 2>/dev/null || echo 2000)
MAX_CORE_INDEX=$((CPU_COUNT - 1))

# Logic Penentuan Core
if [ "$CPU_COUNT" -ge 8 ]; then
    if [ "$FREQ_CORE4" -eq "$FREQ_CORE0" ]; then
        # Pola 6 Little + 2 Big (Khas Mediatek Helio G80/G85/G88/G9x)
        echo "   -> Detected: 6 Little + 2 Big Cores (Mediatek Optimized)"
        little_cores="0-5"
        big_cores="6-$MAX_CORE_INDEX"
    else
        # Pola Standar 4 Little + 4 Big (Snapdragon / Dimensity Modern)
        echo "   -> Detected: 4 Little + 4 Big Cores (Standard Balanced)"
        little_cores="0-3"
        big_cores="4-$MAX_CORE_INDEX"
    fi
    top_cores="0-$MAX_CORE_INDEX"
elif [ "$CPU_COUNT" -ge 6 ]; then
    # Hexa Core
    little_cores="0-1"
    big_cores="2-$MAX_CORE_INDEX"
    top_cores="0-$MAX_CORE_INDEX"
else
    # Quad Core (Entry Level)
    little_cores="0-1" # Sisakan 2 core buat game
    big_cores="2-$MAX_CORE_INDEX"
    top_cores="0-$MAX_CORE_INDEX"
fi

# --- B. EKSEKUSI TWEAK (DEVICE CONFIG) ---

# 1. Manajemen Lalu Lintas Core (CPUSET) + RAM PINNING
{
    # Lempar task background ke Little Core yang sudah dideteksi di atas
    device_config put vendor_system_native background_cpuset "$little_cores"
    device_config put vendor_system_native system_background_cpuset "$little_cores"
    device_config put vendor_system_native restricted_cpuset "$little_cores"

    # --- FITUR ANTI STUTTER (PINNING) ---
    # Mengunci file sistem penting di RAM agar tidak reload
    device_config put system_performance android.app.pinner_service_client_api true
    device_config put system_performance com.android.server.flags.pin_webview true
    
    # Android 14+ Start Info (Mempercepat buka aplikasi)
    device_config put system_performance android.app.app_start_info true
    device_config put system_performance android.app.app_start_info_timestamps true

    # Logic khusus Android 15 (Experimental & Override)
    if [ $(getprop ro.build.version.release) -ge 15 ]; then
         echo "   -> Android 15 Detected: Applying Overrides"
         device_config set_sync_disabled_for_tests persistent
         device_config override vendor_system_native background_cpuset "$little_cores"
         device_config override system_performance android.app.pinner_service_client_api true
         device_config override system_performance com.android.server.flags.pin_webview true
    fi
} > /dev/null 2>&1

# 2. Game ke Semua Core (VIP Access)
{
    # Game (Top App) bebas pakai core manapun (0-7), 
    # tapi sistem akan memprioritaskan Big Core karena load tinggi.
    device_config put vendor_system_native top_app_cpuset "$top_cores"
    device_config put vendor_system_native foreground_cpuset "$top_cores"
} > /dev/null 2>&1

# 3. UClamp Hybrid (Auto-Tuning berdasarkan RAM)
{
    # Jika RAM < 4GB (Entry Level), turunkan sedikit agar tidak overheat
    if [ "$TOTAL_RAM_GB" -lt 4 ]; then
        VAL_BG=20
        VAL_TOP=35 # Cukup 35 biar GPU Mali G-series napas
        VAL_LAT=50
    else
        # RAM Besar / Mid End (Sesuai Request Kamu: 30-40-50)
        VAL_BG=30
        VAL_TOP=40
        VAL_LAT=50
    fi

    # High Scheduling Group (Background penting)
    device_config put runtime_native_boot uclamp_min_high_scheduling_group $VAL_BG
    
    # Top App (GAME KAMU)
    # Memastikan game dapat jatah minimal kapasitas CPU
    device_config put runtime_native_boot uclamp_min_top_app $VAL_TOP
    
    # Latency Sensitive (Touch Input & Rendering)
    # Sangat krusial agar sentuhan tidak delay saat war
    device_config put runtime_native_boot uclamp_min_latency_sensitive $VAL_LAT

} > /dev/null 2>&1


# [80%] BRAND INJECTION
echo "🔓 [||||||||..] 80%  >> 💉 Injecting Brand Modules..."
sleep 0.5

# =========================================================
# 5. BRAND SPECIFIC OPTIMIZATION (FULL RESTORED)
# =========================================================
BRAND=$(getprop ro.product.brand | tr '[:upper:]' '[:lower:]')
MANUFACTURER=$(getprop ro.product.manufacturer | tr '[:upper:]' '[:lower:]')

case "$BRAND" in
    oppo|realme|oneplus)
        # BBK Group (Full List)
        settings put --user 0 system high_performance_mode_on 1
        settings put --user 0 system performance_mode_enable 1
        settings put --user 0 global disturb_for_game_space_mode 1
        settings put --user 0 secure touch_interactions_support 0
        settings delete --user 0 system speed_mode_enable
        settings delete --user 0 global restricted_device_performance
        setprop debug.sys.osie.neednocompress 0
        ;;

    xiaomi|poco|redmi)
        # MIUI/HyperOS (Full List + Animator Sched)
        settings put --user 0 system POWER_PERFORMANCE_MODE_OPEN 1
        settings put --user 0 secure power_performance_tile_enabled 1
        settings put --user 0 global GPUTURBO_SWITCH true
        settings put --user 0 global GPUTUNER_SWITCH false
        settings put --user 0 global miui_memory_size 0
        # Tambahan Smart Sched
        setprop persist.sys.miui_animator_sched.big_prime_cores "$big_cores"
        setprop persist.sys.miui_animator_sched.bigcores "$big_cores"
        ;;

    samsung)
        # Samsung OneUI (Full List)
        settings put --user 0 global restricted_device_performance 0,0
        settings put --user 0 global sem_enhanced_cpu_responsiveness 1
        settings put --user 0 global sem_performance_mode 1
        settings put --user 0 secure game_home_enable 0
        settings put --user 0 secure game_auto_temperature_control 0
        ;;

    itel|infinix|tecno)
        # Transsion (Full List + Aegean Smart Set)
        settings put --user 0 system tran_outdoor_boost_mode 1
        settings put --user 0 system tran_cpupower_mode 1
        setprop persist.sys.gpu_perf_mode true
        setprop sys.force_boost_cpu true
        setprop sys.trancare.performance 1
        # Tambahan Smart Sched Aegean
        setprop sys.tran.aegean.cpu.set.sbg "$big_cores"
        setprop sys.tran.aegean.cpu.set.big "$big_cores"
        ;;
esac

# =========================================================
# 6. GPU VENDOR SPECIFIC
# =========================================================
GPU_TYPE=$(getprop ro.hardware.vulkan | tr '[:upper:]' '[:lower:]')
if echo "$GPU_TYPE" | grep -qi "mali"; then
    setprop debug.mali.disable_backend_affinity true
    setprop debug.mali.backend_affinity false
fi

# [100%] COMPLETED
echo "⚡ [||||||||||] 100% >> ✅ OPTIMIZATION SUCCESS!"
echo ""

# =========================================================
# 7. ENGINE STATUS
# =========================================================
setprop debug.sycox.perfomance.engine on

echo " "
echo " 🔥 SYCOX Perfomance Engine is Active!"
echo "    Mode: Full Performance (Safe/No Overheat)"
echo " "
    
    # Footer Report (Opsional biar makin keren)
echo "📋 SYSTEM REPORT"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  • 💾 RAM Detected  : ${TOTAL_RAM_GB}GB"
echo "  • ⚙️  Core Config   : $CPU_COUNT Cores ($little_cores Little / $big_cores Big)"
echo "  • 🎮 Game Mode     : Active (VIP Access)"
echo "  • 🧬 UClamp Logic  : ${VAL_TOP} (Top App Priority)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🚀 ENJOY THE SPEED!"
echo ""

# ==========================================
# [ADD-ON] ADVANCED DEVICE CONFIG (CLEAN)
# Hanya flag yang terbukti menaikkan performa
# ==========================================
echo "Applying Advanced Flags..."

# 1. PAKSA VULKAN RENDER ENGINE (Penting!)
# Memaksa sistem UI digambar menggunakan Vulkan API (Lebih ringan dari OpenGL)
device_config put core_graphics com.android.graphics.surfaceflinger.flags.vulkan_renderengine true
device_config put core_graphics com.android.graphics.libvulkan.flags.swapchain_mutable_format_ext true

# 2. MULTITHREADED PRESENT (Penting!)
# Memecah tugas menampilkan gambar ke beberapa core CPU (Anti-Bottleneck)
device_config put core_graphics com.android.graphics.surfaceflinger.flags.multithreaded_present true

# 3. REFRESH RATE LOCK (Smooth Display)
# Memaksa layar untuk selalu di refresh rate tertinggi (90/120Hz)
# dan mengabaikan batasan fisik jika memungkinkan.
device_config put display_manager com.android.server.display.feature.flags.back_up_smooth_display_and_force_peak_refresh_rate true
device_config put display_manager com.android.server.display.feature.flags.enable_peak_refresh_rate_physical_limit false

# 4. CPU SET (Multiuser Boost)
# Memastikan semua CPU Core bisa dipakai meskipun ada switch user (jarang terjadi tapi bagus buat jaga-jaga)
device_config put multiuser android.multiuser.use_all_cpus_during_user_switch true

# 5. MATIKAN OVERLAY DEBUG (Biar Bersih)
device_config put core_graphics com.android.graphics.surfaceflinger.flags.refresh_rate_overlay_on_external_display false

    # Performance Magic Tuner
    settings put --user 0 global rendering_type skiavk
    settings put --user 0 global adaptive_battery_management_enabled 0
    settings put --user 0 system background_power_saving_enable 0
    settings put --user 0 secure power_performance_tile_enabled 1
    settings put --user 0 secure power_supersave_tile_enabled 0
    settings put --user 0 global animator_duration_scale 0.1
    settings put --user 0 global transition_animation_scale 0.1
    settings put --user 0 global window_animation_scale 0.1
    settings put --user 0 global dropbox:storage_trim enabled
    settings put --user 0 global storage_trim enabled
    settings put --user 0 global fstrim_mandatory_interval $((365*24*60*60))
    settings put --user 0 global auto_fstrim 0
    settings put --user 0 global mandatory_fstrim_interval $((2*24*60*60*1000))
    settings put --user 0 global fstrim_last_trim_millis $(date +%s%3N)
    settings put --user 0 global looper_stats enabled=false,sampling_interval=0
    settings put --user 0 secure thermal_temp_state_value 0
    settings put --user 0 secure thermal_safety_mode 0
    settings put --user 0 secure game_auto_temperature 0
    settings put --user 0 global warning_temperature 0
    settings put --user 0 global thermal_limit_gpu 0
    settings put --user 0 global enable_temp_dds 0
    settings put --user 0 global battery_tip_constants app_restriction_enabled=false
    settings put --user 0 global art_verifier_verify_debuggable 1
    settings put --user 0 secure high_priority 1
    settings put --user 0 secure doze_enabled 0
    settings put --user 0 secure low_storage_check 0
    settings put --user 0 secure secure_overlay_settings 0
    settings put --user 0 global install_non_market_apps 1
    settings put --user 0 global key_high_volume 1
    settings put --user 0 global ota_disable_automatic_update 1
{
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  🚀 ULTIMATE PERFORMANCE SCRIPT
#  ⚡ Optimized for Android 10 - 15
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# --- Device Detection ---
BRAND=$(getprop ro.product.brand | tr '[:upper:]' '[:lower:]')
MANUFACTURER=$(getprop ro.product.manufacturer | tr '[:upper:]' '[:lower:]')
ANDROID_VER=$(getprop ro.build.version.release)

# --- Header Display ---
clear
echo ""
echo "⚙️  SYSTEM OPTIMIZER INITIATED"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
# Menggunakan tr untuk uppercase tampilan agar aman dari error bad substitution
echo "📱 Device   : $(echo $BRAND | tr 'a-z' 'A-Z') / $(echo $MANUFACTURER | tr 'a-z' 'A-Z')"
echo "🤖 Android  : $ANDROID_VER"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# ==========================================
# CORE: UNIVERSAL TWEAKS
# ==========================================
apply_universal() {
    echo "⚡ Injecting Universal Core..."
    
    # Power & Thermal Base
    cmd power set-adaptive-power-saver-enabled false > /dev/null 2>&1
    cmd power set-mode 0 > /dev/null 2>&1
    cmd power set-fixed-performance-mode-enabled true > /dev/null 2>&1
    
    # Touch & UX Responsiveness
    settings put --user 0 secure long_press_timeout 200
    settings put --user 0 secure multi_press_timeout 100
    settings put --user 0 system pointer_speed 7
    settings put --user 0 system user_experience 1
    
    # Animation Speed (Super Fast - 0.1x)
    settings put --user 0 global animator_duration_scale 0.1
    settings put --user 0 global transition_animation_scale 0.1
    settings put --user 0 global window_animation_scale 0.1

    echo "✅ Core Configuration Active"
}

# ==========================================
# MODULE: PIXEL
# ==========================================
apply_pixel() {
    echo "🎨 Loading Pixel Engine..."
    
    settings put --user 0 system gaming_mode_change_performance_level 1
    settings put --user 0 system gaming_mode_performance_level 6
    
    # Game List Injection
    GAME_LIST=$(cmd package list packages --user 0 | cut -d: -f2 | sed 's/$/=2/' | tr '\n' ',' | sed 's/,$//')
    settings put --user 0 system gamespace_game_list "$GAME_LIST"
    
    settings put --user 0 system gaming_mode_enabled 0
    settings put --user 0 system gaming_mode_dynamic_add true
    settings put --user 0 system gaming_mode_disable_auto_brightness true
    settings put --user 0 system gaming_mode_notification_danmaku false
    settings put --user 0 system gaming_mode_use_game_driver true
    settings put --user 0 system gaming_mode_performance 4
    settings put --user 0 system gaming_mode_disable_notification_alert true
    settings put --user 0 system gaming_mode_disable_ringtone true
    settings put --user 0 system gaming_mode_auto_answer_call false
    settings put --user 0 system gaming_mode_disable_gesture false

    echo "🎮 Pixel Gaming Mode Boosted"
}

# ==========================================
# MODULE: TRANSSION (Infinix/Tecno/Itel)
# ==========================================
apply_transsion() {
    echo "🐅 Loading Transsion Engine..."
    
    # Activity Manager Start
    am start -a com.transsion.batterylab.performance_mode \
        --activity-single-top --activity-clear-top \
        --activity-no-user-action --activity-brought-to-front > /dev/null 2>&1

    setprop persist.sys.user_experience 1
    
    # Specific Settings
    settings put --user 0 system tran_settings_long_battery_auto_open_percentage 0
    settings put --user 0 system power_boost_auto_open_percentage 0
    settings put --user 0 global tran_settings_all_animation_scale 0.1
    settings put --user 0 secure back_gesture_inset_scale_left 1.66
    settings put --user 0 secure back_gesture_inset_scale_right 1.66
    settings put --user 0 system value_vibrate_ontouch 100
    settings put --user 0 system power_boost_frequency 0
    settings put --user 0 system power_boost_frequency_switch 0
    settings put --user 0 system tran_settings_long_battery_frequency_switch 0
    settings put --user 0 system tran_cpupower_mode 1
    settings put --user 0 system tran_outdoor_boost_mode 1
    settings put --user 0 global os_supreme_user_experience 1

    # Intelligent Android Version Check
    if [ "$ANDROID_VER" -le 14 ]; then
        echo "⚠️  Detected Android 14 or Lower"
        PREFIX="device_config put"
        STAGED_PREFIX="device_config put staged"
    else
        echo "⚠️  Detected Android 15+ (Override Mode)"
        PREFIX="device_config override"
        STAGED_PREFIX="device_config override staged"
    fi

    # Config Loop
    for NAMESPACE in tranpm staged; do
        if [ "$NAMESPACE" == "staged" ]; then CMD="$STAGED_PREFIX"; else CMD="$PREFIX"; fi
        NS_TARGET="tranpm"
        [ "$NAMESPACE" == "staged" ] && NS_TARGET="tranpm*com.transsion.performance.tranpm"

        $CMD $NS_TARGET com.transsion.performance.tranpm.delay_start_enable false > /dev/null 2>&1
        $CMD $NS_TARGET com.transsion.performance.tranpm.limit_start_enable false > /dev/null 2>&1
        $CMD $NS_TARGET com.transsion.performance.tranpm.preload_enable true > /dev/null 2>&1
        $CMD $NS_TARGET com.transsion.performance.tranpm.resource_manager_enable true > /dev/null 2>&1
        $CMD $NS_TARGET com.transsion.performance.tranpm.tranpm_reclaim_enable true > /dev/null 2>&1
    done

    echo "✅ XOS/HiOS Optimization Applied"
}

# ==========================================
# MODULE: SAMSUNG
# ==========================================
apply_samsung() {
    echo "🌌 Loading Samsung Engine..."
    
    settings put --user 0 global restricted_device_performance 0,0
    settings put --user 0 global sem_enhanced_cpu_responsiveness 1
    settings put --user 0 global sem_performance_mode 1
    settings put --user 0 global sem_perftune_cpugpu 1
    settings put --user 0 global sem_perftune_ram 1
    settings put --user 0 global sem_turbo_mode 1

    echo "🚀 OneUI Performance Unlocked"
}

# ==========================================
# MODULE: XIAOMI / HYPEROS
# ==========================================
apply_xiaomi() {
    echo "🔥 Loading Xiaomi Engine..."
    
    pm clear --user 0 com.miui.powerkeeper > /dev/null 2>&1
    
    settings put --user 0 global SUPPORT_UGD true
    settings put --user 0 global transition_animation_duration_ratio 0.1
    settings put --user 0 secure power_supersave_tile_enabled 0
    settings put --user 0 secure power_performance_tile_enabled 1
    settings put --user 0 system POWER_PERFORMANCE_MODE_OPEN 1
    settings put --user 0 system POWER_BALANCED_MODE_OPEN 0
    settings put --user 0 system screen_game_mode 1
    settings put --user 0 system perf_rt_enable true
    
    # Game List Injection
    echo "🎮 Generating Game List..."
    PKG_LIST=$(cmd package list packages -3 | cut -f2 -d: | paste -sd, -)
    settings put --user 0 system perf_proc_game_List "$PKG_LIST"
    
    settings put --user 0 global perf_hint_enable true
    settings put --user 0 secure pref_open_game_booster 1
    settings put --user 0 secure speed_mode_enable 1
    settings put --user 0 global DYNAMIC_PERFORMANCE_STATUS 1
    settings put --user 0 global GPUTUNER_SWITCH false

    echo "✅ MIUI/HyperOS Turbo Active"
}

# ==========================================
# MODULE: BBK (OPPO / REALME / ONEPLUS)
# ==========================================
apply_oplus() {
    echo "🟢 Loading BBK Engine..."
    
    settings put --user 0 system high_performance_mode_on 1
    settings put --user 0 system high_performance_mode_on_when_shutdown 1
    settings put --user 0 system performance_mode_enable 1
    
    # Aggressive Battery Killer
    echo "💀 Terminating Battery Managers..."
    pkill -f com.oplus.battery > /dev/null 2>&1
    cmd activity force-stop com.oplus.battery > /dev/null 2>&1
    am force-stop com.oplus.battery > /dev/null 2>&1

    echo "✅ ColorOS/RealmeUI Unleashed"
}

# ==========================================
# EXECUTION FLOW
# ==========================================

# 1. Activate Universal
apply_universal
echo ""

# 2. Activate Specific
case "$BRAND" in
    "google"|"pixel")
        apply_pixel
        ;;
    "itel"|"infinix"|"tecno")
        apply_transsion
        ;;
    "samsung")
        apply_samsung
        ;;
    "xiaomi"|"poco"|"redmi")
        apply_xiaomi
        ;;
    "oppo"|"realme"|"oneplus")
        apply_oplus
        ;;
    "vivo"|"iqoo")
        echo "🔵 Loading Vivo Engine..."
        settings put --user 0 global vivo_screen_refresh_rate_mode 1
        echo "✅ FuntouchOS Standard Boost Applied"
        ;;
    *)
        echo "⚠️  No specific module for $BRAND."
        echo "✅ Running on Universal Engine."
        ;;
esac

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "        🎉 OPTIMIZATION COMPLETED       "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
} 
    
# ==========================================
# ULTIMATE HYBRID SCRIPT (MERGED)
# Optimized for Entry/Mid Level Devices
# ==========================================

echo " "
echo "╔══════════════════════════════════╗"
echo "║  📱 SYSTEM INITIALIZATION...     ║"
echo "╚══════════════════════════════════╝"

# ------------------------------------------
# 1. DETEKSI & VARIABEL (Silent Mode)
# ------------------------------------------
platform=$(getprop ro.board.platform)
chipset=$(getprop ro.soc.manufacturer | tr '[:upper:]' '[:lower:]')
WM_SIZE=$(wm size | head -n 1 | awk '{print $3}')
WIDTH=$(echo $WM_SIZE | cut -d'x' -f1)
HEIGHT=$(echo $WM_SIZE | cut -d'x' -f2)
FPS_DETECT=$(dumpsys display | grep -Eo 'fps=[0-9]+' | cut -f2 -d= | sort -n | uniq | tail -n1)

if [ -z "$FPS_DETECT" ]; then
  FPS_MAX=60
else
  FPS_MAX=$FPS_DETECT
fi

# ==========================================
# 2. CORE RENDERING (PRE-INIT)
# ==========================================
echo "⚡ Mengaktifkan Akselerasi Hardware..."

setprop persist.sys.force_sw_gles 0
setprop debug.egl.hw 1
setprop debug.egl.force_msaa 0 
setprop debug.kill_allocating_task 0
setprop debug.performance.tuning 1

# Input Lag Fix
setprop debug.hwc.fakevsync 0
setprop debug.hwc.logvsync 0

if [ -n "$platform" ]; then
    setprop debug.composition."$platform".type gpu
    setprop debug.sf.composition."$platform".type gpu
fi


# ==========================================
# 3. SMART RENDERER SELECTION (AUTO)
# ==========================================
echo "🔍 Memeriksa Ketersediaan Vulkan..."

vulkan_feature=$(pm list features | grep "android.hardware.vulkan.level")

if [ -n "$vulkan_feature" ]; then
    echo "   ✅ Vulkan API Terdeteksi: AKTIF"
    settings put global rendering_type skiavk
    setprop debug.hwui.default_renderer skiavk
    setprop debug.hwui.renderer skiavk
    setprop debug.renderengine.backend skiavkthreaded
    setprop debug.renderengine.vulkan true
    setprop debug.renderengine.threaded true
    
    # SkiaVK Optimization
    setprop debug.hwui.use_gpu_pixel_buffers true
    setprop debug.hwui.use_buffer_age false
    setprop debug.hwui.app_memory_policy_size 1024
    
    # Matikan Validasi
    setprop debug.vulkan.layers.enable 0
    setprop debug.vulkan.layers.disable_all 1
    
    device_config put core_graphics com.android.graphics.libvulkan.flags.swapchain_mutable_format_ext true
    device_config put core_graphics com.android.graphics.surfaceflinger.flags.vulkan_renderengine true
else
    echo "   ⚠️ Vulkan Tidak Tersedia: Fallback ke OpenGL"
    settings put global rendering_type skiagl
    setprop debug.hwui.default_renderer skiagl
    setprop debug.hwui.renderer skiagl
    setprop debug.renderengine.vulkan false
    setprop debug.renderengine.backend skiaglthreaded
    
    setprop debug.hwui.use_buffer_age false
    setprop debug.hwui.use_gpu_pixel_buffers true
    
    device_config put core_graphics com.android.graphics.libvulkan.flags.swapchain_mutable_format_ext false
    device_config put core_graphics com.android.graphics.surfaceflinger.flags.vulkan_renderengine false
fi

# ==========================================
# 4. SAFE GRALLOC (UBWC)
# ==========================================
echo "🧊 Mengaktifkan Efisiensi Bandwidth (UBWC)..."

setprop debug.gralloc.enable_fb_ubwc 1
setprop debug.gralloc.gfx_ubwc_disable 0
setprop debug.gralloc.map_fb_memory 0
setprop persist.sys.force_highendgfx false
setprop debug.gfx.driver 0 

# ==========================================
# 5. TOUCH & UI OPTIMIZATION
# ==========================================
echo "👆 Mengkalibrasi Responsivitas Sentuhan..."

settings put global window_animation_scale 0.25
settings put global transition_animation_scale 0.25
settings put global animator_duration_scale 0.25
settings put system pointer_speed 7
settings put secure touch_blocking_period 0
settings put secure tap_duration_threshold 0

cmd device_config put latency_tracker enabled false
cmd device_config put interaction_jank_monitor enabled false
device_config put input dispatcher_low_latency true
device_config put input input_dispatch_resolution_ns 1000000

# ==========================================
# 6. CLEANUP & NOTIFICATION PERFORMANCE FIX
# ==========================================
echo "🧹 Membersihkan Cache & Optimize Overlay..."

# 1. Visual Tweak (Sesuai settingan kamu)
setprop debug.sf.disable_blurs 1
setprop debug.sf.enable_advanced_dithering 0
setprop debug.sf.disable_client_composition_cache 1 
# ^ Ubah ke 1 (Disable Cache), biar RAM gak penuh nyimpen cache layer UI

# 2. Composition Strategy (FIX NOTIF LAG)
# Jangan force GPU kalau GPU lagi load berat.
# Biarkan Hardware Composer (HWC) yang nentuin secara dinamis.
setprop debug.hwc.force_gpu 0 

# 3. DRM & Rendering (Pastiin variabel WIDTH/HEIGHT ada di atas script!)
# setprop debug.drm.mode.force ${WIDTH}x${HEIGHT}@${FPS_MAX} 
# ^ Hati-hati, uncomment cuma kalau variabel sudah didefinisikan!

setprop debug.hwui.skia_atrace_enabled false
setprop debug.hwui.skia_tracing_enabled false
setprop debug.egl.checkGlError 0

# 6. Refresh Layar (GANTI METODE)
# Jangan pakai keyevent 26 (matiin layar), pakai ini biar redraw tanpa matiin layar:
service call activity 1599295570 > /dev/null 2>&1
echo "   🔄 UI Redraw Triggered..."

echo " ✅ SYCOX: Done. Notification Lag Optimized."


# ==========================================
# 7. ADVANCED SURFACEFLINGER
# ==========================================
echo "🌊 Mengaktifkan 'Butter Smooth' UI..."

setprop debug.sf.max_igbp_buffers 3
setprop debug.sf.enable_gl_backpressure 1
setprop debug.sf.enable_hwc_vds 0
setprop debug.sf.predict_composition_strategy 1
setprop debug.sf.treat_170m_as_sRGB 1
setprop debug.sf.disable_client_composition_cache 0
setprop debug.sf.enable_transaction_tracing 0

# ==============================================
# 8. SMART DALVIK THREADS
# ==============================================
cpu_count=$(grep -c ^processor /proc/cpuinfo)
if [ "$cpu_count" -ge 8 ]; then
    safe_threads=6
elif [ "$cpu_count" -ge 6 ]; then
    safe_threads=4
else
    safe_threads=2
fi

echo "🧠 Mengatur Compiler Threads: $safe_threads Core (Safe Mode)"
setprop dalvik.vm.dex2oat-threads "$safe_threads"
setprop dalvik.vm.boot-dex2oat-threads "$safe_threads"
setprop dalvik.vm.image-dex2oat-threads "$safe_threads"

# ==========================================
# 9. HWUI EXTRA (FIXED: Now with Echo)
# ==========================================
echo "🎨 Mengoptimalkan HWUI Rendering..." 

setprop debug.hwui.render_thread_count 2
setprop debug.hwui.overdraw false
setprop debug.hwui.show_overdraw false

# ==============================================
# 10. ADPF DYNAMIC LITE (STABLE & FMQ)
# ==============================================
echo "🎮 Mengaktifkan ADPF Lite + FMQ (No Overhead)..."

# --- 1. Basic Activation (Tanpa Prediksi Berat) ---
setprop debug.sf.enable_adpf_cpu_hint true
setprop debug.hwui.use_hint_manager true
setprop debug.sf.trace_hint_sessions false

# --- 2. Hint Strategy (Anti Spam) ---
# Matikan early hint (sering bikin lag di hp kentang), aktifkan late hint saja
setprop debug.sf.send_early_power_session_hint false
setprop debug.sf.send_late_power_session_hint true
setprop debug.sf.normalize_hint_session_durations true

# --- 3. Reduce Overhead (PENTING BUAT ENTRY LEVEL) ---
# Matikan reporting durasi kerja GPU ke CPU (biar CPU gak sibuk ngitung)
setprop debug.adpf.use_report_actual_duration false
device_config put game android.os.adpf_gpu_report_actual_work_duration false
# Margin nol biar presisi
setprop debug.sf.allowed_actual_deviation 0
setprop debug.sf.hint_margin_us 0

# --- 4. Mediatek Specific Bypass ---
# Cek otomatis chipset, kalau MTK aktifkan bypass hint biar gak bentrok
chipset=$(getprop ro.soc.manufacturer | tr '[:upper:]' '[:lower:]')
chipset2=$(getprop ro.hardware.soc.manufacturer | tr '[:upper:]' '[:lower:]')
if echo "$chipset $chipset2" | grep -qi "mediatek"; then
    setprop debug.mtk.powerhal.hint.bypass 1
fi

# --- 5. FMQ (Fast Message Queue) Optimization ---
# Jalur cepat komunikasi data, biar fps lebih 'nurut'
device_config put game android.os.adpf_use_fmq_channel true
device_config put game android.os.adpf_use_fmq_channel_fixed true
device_config put game android.os.adpf_fmq_eager_send true
device_config put game com.android.graphics.surfaceflinger.flags.adpf_fmq_sf true
device_config put game com.android.graphics.surfaceflinger.flags.adpf_native_session_manager true

# --- 6. Boost Logic ---
# Boost saat sentuh layar & buka view (Biar responsif)
device_config put game android.os.adpf_measure_during_input_event_boost true
device_config put game android.os.adpf_obtainview_boost true

# --- 7. Stability Guard ---
# Matikan Power Efficiency (Paksa performa stabil)
device_config put game android.os.adpf_platform_power_efficiency false
device_config put game android.os.adpf_prefer_power_efficiency false
# Cleanup thread biar gak numpuk di RAM
device_config put game com.android.server.power.hint.powerhint_thread_cleanup true

# --- 8. UI Thread Safety ---
# JANGAN GUNAKAN FIFO (1) DI HP ENTRY LEVEL -> Bikin Freeze/Stutter
setprop sys.use_fifo_ui 0
# Gunakan boost standar saja
setprop persist.sys.perf.topAppRenderThreadBoost.enable true

# ==============================================
# 11. VSYNC TIMING RESTORE
# ==============================================
echo "⏱️  Mereset VSync Timing ke Default..."

setprop debug.sf.early.app.duration ""
setprop debug.sf.earlyGl.app.duration ""
setprop debug.sf.early.sf.duration ""
setprop debug.sf.earlyGl.sf.duration ""
setprop debug.sf.late.app.duration ""
setprop debug.sf.late.sf.duration ""
setprop debug.sf.early_app_phase_offset_ns ""
setprop debug.sf.early_gl_app_phase_offset_ns ""
setprop debug.sf.early_phase_offset_ns ""
setprop debug.sf.early_gl_phase_offset_ns ""
setprop debug.sf.high_fps.early.app.duration ""
setprop debug.sf.high_fps.earlyGl.app.duration ""
setprop debug.sf.high_fps.late.app.duration ""
setprop debug.sf.high_fps.late.sf.duration ""
setprop debug.sf.latch_unsignaled 0

# =============================================================
# 12. CMD DISABLE TRACING
# =============================================================
echo "🚫 Mematikan System Tracing (Deep Clean)..."

cmd window tracing stop
cmd window tracing size 0
cmd input_method tracing stop
cmd accessibility stop-trace
cmd activity trace-ipc stop
cmd activity trace-save-for-bugreport 0
setprop debug.atrace.tags.enableflags 0
setprop persist.traced.enable 0

# ==========================================
# 13. BACKGROUND PROCESS MANAGER
# ==========================================
echo "🛡️  Mengamankan Manajemen RAM..."

device_config put activity_manager max_phantom_processes 2147483647
device_config put activity_manager boot_time_max_phantom_processes 2147483647
device_config put activity_manager max_cached_processes 16
device_config put activity_manager max_empty_time_millis 43200000
settings put global always_finish_activities 0

echo " "
echo "╔══════════════════════════════════╗"
echo "║      ✨  OPTIMASI SELESAI  ✨    ║"
echo "║    Device is Ready for Gaming    ║"
echo "╚══════════════════════════════════╝"
echo " "



# ==========================================
# PURE PERFORMANCE & TOUCH (NO GIMMICK)
# Verified Props Only - Entry/Mid Level Safe
# ==========================================

echo "Starting Optimization..."

# 1. GPU RENDERING (Visual Responsiveness)
# ------------------------------------------
# Memaksa rendering UI ke GPU.
# Catatan: 'persist' mungkin tidak nempel setelah reboot di non-root, 
# tapi akan aktif selama sesi ini.
setprop debug.composition.type gpu
setprop debug.sf.disable_backpressure 1
setprop debug.cpurend.vsync false

# 2. TOUCH OPTIMIZATION (Fix Frame Drop)
# ------------------------------------------
# MATIKAN Touchboost! 
# Ini rahasia agar HP entry level tidak cepat panas saat jari nempel di analog.
setprop sys.input.resample.latency 1

# 3. UI PERFORMANCE (Anti-Lag & Safe Mode)
# ------------------------------------------
# Mematikan efek Blur adalah WAJIB untuk HP Entry Level.
setprop persist.sys.background_blur_keyguard_disabled true
setprop persist.sys.background_blur_supported false
setprop persist.sys.background_blur_status_default false

# ==========================================
# 4. CHIPSET SPECIFIC OPTIMIZATION
# Support: MediaTek & Qualcomm Snapdragon
# ==========================================
echo ">>> Checking Chipset Specific Tweaks..."

# Menggunakan variabel $chipset & $chipset2 yang sudah dideteksi di Section 1
# Gabungkan agar deteksi lebih akurat
CHIPSET_FULL="$chipset $chipset2"

if echo "$CHIPSET_FULL" | grep -qi "mediatek"; then
    echo "   -> MediaTek Detected. Applying GamePQ & NNAPI."
    
    # Game Picture Quality (Visual Enhancer)
    # Mengaktifkan pemrosesan gambar khusus game bawaan MTK
    setprop debug.mediatek.game_pq_debug 0
    setprop debug.mediatek.game_pq_enable 1
    setprop debug.mediatek.appgamepq 2
    
    # Texture Compression (Performa Loading)
    setprop debug.mediatek.disp_decompress 1
    setprop debug.mediatek.appgamepq_compress 1
    
    # AI Acceleration (NNAPI)
    # Memaksa penggunaan Neural Network API level 29 (Android 10) yang stabil
    setprop debug.mtk_tflite.target_nnapi 29

elif echo "$CHIPSET_FULL" | grep -qi "qualcomm"; then
    echo "   -> Snapdragon Detected. Optimizing HW Flags."
    
    # Disable Sensor Debugging (Mengurangi Overhead CPU)
    # Mematikan logging sensor yang tidak perlu saat gaming
    setprop debug.qualcomm.sns.hal 0
    setprop debug.qualcomm.sns.daemon 0
    setprop debug.qualcomm.sns.libsensor1 0
    
    # Hardware Acceleration Flags
    setprop debug.qctwa.statusbar 1
    setprop debug.qctwa.preservebuf 1
    setprop debug.qc.hardware true

else
    echo "   -> Other Chipset (Exynos/Unisoc/Kirin). Skipping specific tweaks."
fi


# 5. POWER MANAGEMENT (Stable)
# ------------------------------------------
# Gunakan Mode 0 (INTERACTIVE).
# Membiarkan CPU naik turun sesuai kebutuhan game secara natural.
# Mode 1 (Sustained) justru menahan performa maksimal.
cmd power set-mode 0

# 6. LOG & TRACE CLEANUP
# ------------------------------------------
# Mematikan logging grafis yang tidak perlu.
setprop debug.egl.profiler 0
setprop debug.egl.trace ""
setprop debug.mdpcomp.logs 0

# 7. SMART MEMORY MANAGEMENT (Device Config)
# ------------------------------------------
# Ini adalah metode paling ampuh untuk Non-Root di Android modern.
API_LEVEL=$(getprop ro.build.version.sdk)

if [ "$API_LEVEL" -ge 29 ]; then
    echo "  -> Optimizing LMKD for Android 10+..."
    
    # Mencegah aplikasi foreground (Game) dibunuh tiba-tiba
    device_config put lmkd_native thrashing_limit 100
    device_config put lmkd_native thrashing_limit_critical 100
    device_config put lmkd_native kill_heaviest_task true
    device_config put lmkd_native kill_timeout_ms 100
    
    # Khusus Android 14/15 agar settingan tidak di-reset sistem
    if [ "$API_LEVEL" -ge 34 ]; then
        device_config set_sync_disabled_for_tests persistent
    fi
else
    echo "  -> Legacy Android detected. Skipping Device Config."
fi

# 8. STORAGE TRIM (Pengganti Memory Factor)
# ------------------------------------------
# Daripada memalsukan RAM penuh, lebih baik kita rapikan block storage.
# Ini mengurangi lag saat loading texture game.
# (Command ini mungkin butuh waktu beberapa detik)
echo "  -> Trimming storage blocks..."
sm fstrim

echo "=========================================="
echo " DONE! OPTIMIZATION APPLIED."
echo "=========================================="

echo ""
echo "╔═══════════════════════════════════════╗"
echo "║   🚀 RENSHIP MODULE - STATUS REPORT   ║"
echo "╚═══════════════════════════════════════╝"
echo " ➤ GPU Acceleration   : 🟢 ENGAGED [Hardcoded]"
echo " ➤ Thermal Service    : 🧊 KILLED [Bypassed]"
echo " ➤ Touch Latency      : ⚡ INSTANT [0ms Delay]"
echo " ➤ FPS Stabilizer     : 🔒 LOCKED"
echo " ➤ Rendering Backend  : 🎨 SkiaVK / OpenGL"
echo " ➤ SYCOX ENGINE       : 🔥 VVIP ACTIVE"
echo "─────────────────────────────────────────"
echo ""

echo "🔍 Melakukan Diagnosa Sistem..."

# 1. Cek Render (Fix Broken Pipe)
echo -n "   👉 Cek Visual Pipeline : "
if dumpsys gfxinfo 2>/dev/null | grep -q "Skia"; then
    echo "[ ✅ VULKAN/SKIA DETECTED ]"
elif [ "$(getprop debug.hwui.renderer)" = "skiavk" ]; then
    echo "[ ✅ SKIAVK FORCED ON ]"
else
    echo "[ ⚠️ OPENGL FALLBACK ]"
fi

# 2. Cek Thermal
echo -n "   👉 Cek Thermal Bypass  : "
if dumpsys thermalservice 2>/dev/null | grep -q "99.999"; then
    echo "[ ✅ SUKSES - DUMMY VALUE ]"
else
    # Cek alternatif
    if dumpsys thermalservice 2>/dev/null | grep -q "Status: 0"; then
         echo "[ ✅ OPTIMAL / COOLED ]"
    else
         echo "[ ⚠️ SYSTEM DEFAULT ]"
    fi
fi

# 3. Cek Game Overlay (Hitung jumlah saja)
count=$(device_config list 2>/dev/null | grep -c "game_overlay")
echo -n "   👉 Game Configs        : "
if [ "$count" -gt 0 ]; then
    echo "🎮 $count App Configured"
else
    echo "❌ None Active"
fi

# 4. Cek Resolusi
echo -n "   👉 Display Mode        : "
res=$(cmd display get-user-preferred-display-mode 0 2>/dev/null | grep -oE '[0-9]+x[0-9]+ [0-9.]+')
if [ -n "$res" ]; then
    echo "🖥️ $res"
else
    width=$(getprop ro.sf.lcd_density) 
    echo "📱 Density: $width dpi"
fi

echo ""
echo "========================================="
echo "   ✨ INSTALASI SELESAI (NO ERROR) ✨"
echo "========================================="

# Notifikasi
cmd notification post -t "RENSHIP MODULE" -i "@android:drawable/stat_sys_upload_done" installtag "🔥 SYCOX Engine: MAXIMUM PERFORMANCE" >/dev/null 2>&1
}
else
memory=$(cat /proc/meminfo)
uptime=$(cat /proc/uptime | awk '{print int($1)}')

# Fix CPU freq
cpu_freq_raw=$(cat /sys/devices/system/cpu/cpufreq/*/cpuinfo_max_freq 2>/dev/null | tail -n1)
cpu_freq=$(awk -v freq="$cpu_freq_raw" 'BEGIN { printf("%.3f", freq/1000000) }')

# Auto detect working thermal zone
temp=""
for zone in /sys/class/thermal/thermal_zone*/temp; do
  val=$(cat "$zone" 2>/dev/null)
  if [ "$val" != "" ] && [ "$val" -gt 0 ] && [ "$val" -lt 200000 ]; then
    temp=$val
    break
  fi
done

# Convert to °C or set unknown
if [ "$temp" != "" ]; then
  temp_c=$(awk -v t="$temp" 'BEGIN { printf("%d", t/1000) }')
else
  temp_c="Unknown"
fi

echo "┌────────────────────────────────────────────────────────┐"
echo "│            📱 DEVICE & HARDWARE INFORMATION            │"
echo "├────────────────────────────────────────────────────────┤"
echo "│ 🧩 OS         : Android $(getprop ro.build.version.release)"
echo "│ 📱 Model      : $(getprop ro.product.manufacturer) $(getprop ro.product.model)"
echo "│ 🐧 Kernel     : $(uname -r | cut -f1,2,3 -d-)"
echo "│ ⏱️ Uptime     : $((uptime/3600)) hour, $((uptime%3600/60)) mins"
echo "│ 📦 Packages   : $(cmd package list packages -s --user 0 | wc -l) (sys), $(cmd package list packages -3 --user 0 | wc -l) (trd)"
echo "│ 🖥️ Resolution : $(wm size | cut -d: -f2)"
echo "│ 🎨 Theme      : $(getprop ro.build.fingerprint | tr '/' '\n' | grep user | cut -f1 -d:)"
echo "│ 💻 Terminal   : $(cmd activity stack list | grep 0,0.*visible=true | tr -d ' ' | cut -f1 -d/ | cut -f2 -d:)"
echo "│ ⚙️ CPU        : $(getprop ro.soc.manufacturer) $(getprop ro.soc.model) ($(grep -c proc /proc/cpuinfo)) @ ${cpu_freq} GHz"
echo "│ 🎮 GPU        : $(dumpsys SurfaceFlinger | grep GLES: | cut -f2 -d,)"
echo "│ 🧠 Memory     : $((($(echo \"$memory\" | grep MemTotal | awk '{print $2}')-$(echo \"$memory\" | grep MemAvailable | awk '{print $2}'))/1024))MiB / $(($(echo \"$memory\" | grep MemTotal | awk '{print $2}')/1024))MiB"
echo "│ 🌡️ Thermal    : ${temp_c}°C"
echo "│ 🧱 Build      : $(getprop ro.build.display.id)"
echo "│ 🔑 Root       : $(if [ $(id -u) -eq 0 ]; then echo Yes; else echo No; fi)"
echo "│ 🛡️ SELinux    : $(getenforce)"
echo "└────────────────────────────────────────────────────────┘"

echo "█▓▒▒░░░WELCOME TO DELETION░░░▒▒▓█"
echo ""
sleep 0.5
echo ""
echo " 
██████╗░███████╗███╗░░██╗███╗░░██╗
██╔══██╗██╔════╝████╗░██║████╗░██║
██████╔╝█████╗░░██╔██╗██║██╔██╗██║
██╔══██╗██╔══╝░░██║╚████║██║╚████║
██║░░██║███████╗██║░╚███║██║░╚███║
╚═╝░░╚═╝╚══════╝╚═╝░░╚══╝╚═╝░░╚══╝ "

# __________________________________________

echo "🔄 Memulai proses restore ke default..."
echo "__________________________________________"

# ==========================================
# 1. RESET TAMPILAN & REFRESH RATE
# ==========================================
echo "🖥️ Mereset Display & FPS..."

# Hapus preferensi user (Lock FPS)
cmd display clear-user-preferred-display-mode
cmd display set-match-content-frame-rate-pref 0

# Hapus settingan sistem refresh rate
settings delete system peak_refresh_rate
settings delete system min_refresh_rate
settings delete system user_refresh_rate

# Hapus properti debug display
setprop debug.sf.default_refresh_rate ""
setprop debug.sf.frame_rate_multiple_threshold ""

# Reset Mediatek props (Jika ada)
setprop debug.mediatek.high_frame_rate_multiple_display_mode ""
setprop debug.mediatek.high_frame_rate_sf_set_big_core_fps_threshold ""

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  🔄 POWER & SYSTEM RESTORE DEFAULT
#  🔙 Revert Power Management to Factory
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

echo ""
echo "♻️  RESTORING SYSTEM DEFAULTS..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# 1. RESTORE CORE POWER COMMANDS
# Mengaktifkan kembali Adaptive Power Saver (Default Android)
cmd power set-adaptive-power-saver-enabled true > /dev/null 2>&1
# Mematikan Fixed Performance Mode
cmd power set-fixed-performance-mode-enabled false > /dev/null 2>&1

# 2. RESTORE SYSTEM & STATS
# Mengembalikan Looper Stats ke default (biasanya enabled)
cmd looper_stats enable > /dev/null 2>&1
# Menghapus override uidcpupower
settings delete --user 0 global sys_uidcpupower
settings delete --user 0 global looper_stats

# 3. RESTORE BATTERY SAVER SETTINGS
settings delete --user 0 system background_power_saving_enable
settings delete --user 0 global adaptive_battery_management_enabled

# Restore Battery Tips (Biarkan sistem mengelola tips)
settings delete --user 0 global battery_tip_constants

# Restore Battery Saver Constants
settings delete global battery_saver_adaptive_device_specific_constants
settings delete global battery_saver_adaptive_constants
settings delete --user 0 global battery_saver_constants

# 4. RESTORE DOZE & IDLE (PENTING: Agar baterai tidak boros saat diam)
settings delete --user 0 global device_idle_constants

# 5. RESTORE ACTIVITY MANAGER & RAM
# Mematikan paksaan GPU Rendering (Kembali ke Auto/Default)
settings delete --user 0 global force_gpu_rendering

# Restore Battery Stats Logging
settings delete --user 0 global battery_stats_constants

# Restore Activity Manager & App Ops Constants
settings delete --user 0 global app_ops_constants
settings delete --user 0 global activity_manager_constants

# 6. RESTORE STANDBY & RESTRICTION
settings delete --user 0 global power_manager_constants
settings delete --user 0 global kernel_cpu_thread_reader
settings delete --user 0 global forced_app_standby_for_small_battery_enabled
settings delete --user 0 global forced_app_standby_enabled
settings delete --user 0 global app_auto_restriction_enabled
settings delete --user 0 global app_standby_enabled
settings delete --user 0 global app_idle_constants
settings delete --user 0 global display_panel_lpm
settings delete --user 0 global dynamic_power_savings
settings delete --user 0 global dynamic_power_savings_disable_threshold
settings delete --user 0 global dynamic_power_savings_enabled

# 7. RESTORE LOW POWER MODE (Agar fitur hemat baterai bisa jalan lagi saat lowbat)
settings delete --user 0 global low_power
settings delete --user 0 global low_power_sticky
settings delete --user 0 global low_power_sticky_auto_disable_level
settings delete --user 0 global low_power_sticky_auto_disable_enabled
settings delete --user 0 global low_power_trigger_level
settings delete --user 0 global low_power_trigger_level_max
settings delete --user 0 global low_power_mode_suggestion_params
settings delete --user 0 global automatic_power_save_mode
settings delete --user 0 secure sysui_tuner_version

echo "✅ Power Management Reset Complete"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"


# ==========================================
# 3. BERSIHKAN CONFIG GAME & APP
# ==========================================
echo "🧹 Membersihkan Config per Aplikasi..."

# FIX: Tambahkan tr -d '\r' agar nama paket bersih saat dihapus
ALL_USER_APPS=$(cmd package list packages -3 | cut -f 2 -d ":" | tr -d '\r')

# Nyalakan kembali looper stats (Default)
cmd looper_stats enable

for app in $ALL_USER_APPS; do
    # Lewati jika error/kosong/manager sendiri
    if [ -z "$app" ]; then continue; fi
    if [ "$app" = "com.frb.axmanager" ]; then continue; fi # Safety biar manager gak kereset paksa
    
    # 1. Hapus konfigurasi overlay (Game Dashboard)
    device_config delete game_overlay "$app" > /dev/null 2>&1
    
    # 2. Reset mode game ke STANDARD (Bawaan)
    cmd game mode standard "$app" > /dev/null 2>&1
    
    # 3. Matikan downscale & Reset total
    cmd game set --downscale disable "$app" > /dev/null 2>&1
    cmd game reset "$app" > /dev/null 2>&1
done

echo "✅ Config aplikasi bersih."

# ==========================================
# 4. RESET DRIVER GRAFIS
# ==========================================
echo "🎨 Mereset Driver Grafis..."

# Hapus daftar driver custom/system override
settings delete global game_driver_opt_in_apps
settings delete global game_driver_prerelease_opt_in_apps
settings delete global game_driver_opt_out_apps
settings delete global game_driver_all_apps # Hapus paksaan all apps yg tadi ada di installer

# Hapus sisa-sisa ANGLE & Debug
settings delete global angle_gl_driver_selection_pkgs
settings delete global angle_gl_driver_selection_values
settings delete global angle_debug_package
settings delete global angle_gl_driver_all_angle

# ==========================================
# 5. RESET SYSTEM PROPERTIES (Runtime)
# ==========================================
echo "🔄 Mengembalikan System Properties..."

# Mengembalikan nilai properti umum ke default aman
setprop sys.touchboost.enabled ""
setprop persist.sys.hardcoder.name ""
setprop debug.hwc.force_gpu 0
# debug.composition.type defaultnya biasanya 'c2d' atau 'dyn', kosongkan saja biar balik ke init
setprop debug.composition.type "" 
setprop debug.egl.profiler 1
setprop debug.egl.trace ""
setprop debug.sf.enable_transaction_tracing true

echo "__________________________________________"
echo "✅ RESTORE SELESAI!"
echo "⚠️ SANGAT DISARANKAN UNTUK REBOOT HP ANDA"
echo "   AGAR SEMUA PERUBAHAN SYSTEM PROP BERSIH TOTAL."
echo "__________________________________________"

    {
# =========================================================
#  🚫 SYCOX Perfomance Engine - UNINSTALLER
#  Action: Revert to Stock / Default Settings
# =========================================================

echo " "
echo " [■□□□□□□□□□] 10% - Stopping Services..."
sleep 0.5

# =========================================================
# 1. REVERT VISUAL & RENDERING (Back to Default)
# =========================================================
# Kembalikan rendering ke komposisi default
setprop debug.sf.hw 0
setprop debug.egl.hw 0
setprop debug.composition.type dyn
setprop debug.hwui.renderer skiagl
setprop debug.hwui.use_gpu_pixel_buffers false
setprop debug.hwui.force_gpu_for_2d false

# Aktifkan kembali buffer cleaning standar
setprop debug.hwui.render_dirty_regions ""
setprop debug.hwui.show_dirty_regions ""
setprop debug.hwui.skip_empty_damage false

# Kembalikan pengaturan refresh rate & idle timer
setprop debug.sf.enable.refreshrate.30hz 1
setprop debug.sf.predict_hwc_composition_strategy 1
setprop debug.sf.support_kernel_idle_timer true
setprop debug.sf.support_kernel_idle_timer_enabled true
setprop debug.sf.set_touch_timer_ms ""
setprop debug.sf.default_idle_timer_ms ""

# Aktifkan kembali Blur (Tampilan default Android)
setprop debug.sf.disable_blurs 0
setprop debug.sf.use_background_blur 1
setprop debug.sf.latch_unsignaled 0

echo " [■■■■□□□□□□] 40% - Resetting Touch..."
sleep 0.5

# =========================================================
# 2. REVERT TOUCH SETTINGS (Stock)
# =========================================================
# Kembalikan TouchBoost ke pengaturan kernel (biasanya 1/auto)
setprop sys.touchboost.enabled 1
setprop sys.input.boost.enabled false

# Kembalikan latensi ke normal (1.0)
setprop debug.touch_sensitivity_mode 0
setprop debug.touchscreen.latency.scale 1.0
setprop debug.input.avg_event_time 1
setprop debug.tracing.block_touch_buffer 0
setprop persist.sys.touch.tuning false
setprop persist.sys.enable_sched_touchdown false
setprop debug.vendor.perf.smart_touch 0

echo " [■■■■■■□□□□] 60% - Clearing CPU Topology..."
sleep 0.5

# =========================================================
# 3. REVERT PERFORMANCE & BATTERY (Stock)
# =========================================================
# Aktifkan kembali Adaptive Battery (Penghemat Baterai Standar)
settings put --user 0 global adaptive_battery_management_enabled 1
settings put --user 0 system background_power_saving_enable 1
cmd power set-adaptive-power-saver-enabled true
setprop debug.power_management_mode normal

# Kembalikan prioritas standar
setprop debug.performance.tuning 0
setprop persist.sys.cpulimit.enable true
setprop debug.kill_allocating_task true

# Kembalikan Phantom Process
setprop sys.fflag.override.settings_enable_monitor_phantom_procs true
device_config delete activity_manager max_phantom_processes > /dev/null 2>&1

# =========================================================
# 4. CLEAR DEVICE CONFIG (CPU Topology Reset)
# =========================================================
# Menghapus paksaan cpuset agar kembali diatur oleh sistem
{
    # Hapus konfigurasi Native
    device_config delete vendor_system_native background_cpuset
    device_config delete vendor_system_native system_background_cpuset
    device_config delete vendor_system_native restricted_cpuset
    device_config delete vendor_system_native top_app_cpuset
    device_config delete vendor_system_native foreground_cpuset
    
    # Hapus tweak Android 14/15
    device_config delete system_performance android.app.app_start_info
    device_config delete system_performance android.app.app_start_info_timestamps
    device_config delete system_performance com.android.server.flags.pin_webview
    
    # Hapus UClamp Override
    device_config delete runtime_native_boot uclamp_min_high_scheduling_group
    device_config delete runtime_native_boot uclamp_min_top_app
    device_config delete runtime_native_boot uclamp_min_latency_sensitive
} > /dev/null 2>&1

echo " [■■■■■■■■□□] 80% - Reverting Brand Tweaks..."
sleep 0.5

# =========================================================
# 5. REVERT BRAND SPECIFIC
# =========================================================
BRAND=$(getprop ro.product.brand | tr '[:upper:]' '[:lower:]')

case "$BRAND" in
    oppo|realme|oneplus)
        settings put --user 0 system high_performance_mode_on 0
        settings put --user 0 system performance_mode_enable 0
        settings put --user 0 global disturb_for_game_space_mode 0
        settings put --user 0 secure touch_interactions_support 1
        ;;

    xiaomi|poco|redmi)
        settings put --user 0 system POWER_PERFORMANCE_MODE_OPEN 0
        settings put --user 0 secure power_performance_tile_enabled 0
        settings put --user 0 global GPUTURBO_SWITCH false
        setprop persist.sys.miui_animator_sched.big_prime_cores ""
        ;;

    samsung)
        settings put --user 0 global restricted_device_performance 1
        settings put --user 0 global sem_enhanced_cpu_responsiveness 0
        settings put --user 0 secure game_home_enable 1
        ;;

    itel|infinix|tecno)
        settings put --user 0 system tran_outdoor_boost_mode 0
        setprop sys.trancare.performance 0
        setprop persist.sys.gpu_perf_mode false
        ;;
esac

# =========================================================
# 6. GPU REVERT
# =========================================================
setprop debug.mali.disable_backend_affinity false
setprop debug.mali.backend_affinity true

echo " [■■■■■■■■■■] 100% - Uninstalled Successfully!"
sleep 0.5

# =========================================================
# 7. ENGINE STATUS (OFF)
# =========================================================
setprop debug.sycox.perfomance.engine off

echo " "
echo " 🚫 SYCOX Perfomance Engine is OFF"
echo "    Settings reverted to Default/Stock."
echo "    Please REBOOT your device."
echo " "

# ==========================================
# [ADD-ON] DELETE DEVICE CONFIG
# Menghapus override agar kembali ke default pabrik
# ==========================================
echo "Deleting Advanced Flags..."

# 1. DELETE VULKAN FLAGS
device_config delete core_graphics com.android.graphics.surfaceflinger.flags.vulkan_renderengine
device_config delete core_graphics com.android.graphics.libvulkan.flags.swapchain_mutable_format_ext

# 2. DELETE MULTITHREADED PRESENT
device_config delete core_graphics com.android.graphics.surfaceflinger.flags.multithreaded_present

# 3. DELETE REFRESH RATE LOCK
device_config delete display_manager com.android.server.display.feature.flags.back_up_smooth_display_and_force_peak_refresh_rate
device_config delete display_manager com.android.server.display.feature.flags.enable_peak_refresh_rate_physical_limit

# 4. DELETE CPU SET
device_config delete multiuser android.multiuser.use_all_cpus_during_user_switch

# 5. DELETE OVERLAY SETTINGS
device_config delete core_graphics com.android.graphics.surfaceflinger.flags.refresh_rate_overlay_on_external_display

echo "Uninstall Complete."
echo "Please REBOOT your device to apply all changes cleanly."

    # Performance Magic Tuner
    settings put --user 0 global rendering_type skiagl
    settings put --user 0 global adaptive_battery_management_enabled 1
    settings put --user 0 system background_power_saving_enable 1
    settings put --user 0 secure power_performance_tile_enabled 0
    settings put --user 0 secure power_supersave_tile_enabled 1
    settings put --user 0 global animator_duration_scale 1.0
    settings put --user 0 global transition_animation_scale 1.0
    settings put --user 0 global window_animation_scale 1.0
    settings put --user 0 global dropbox:storage_trim disabled
    settings put --user 0 global storage_trim disabled
    settings put --user 0 global fstrim_mandatory_interval 
    settings put --user 0 global auto_fstrim 0
    settings put --user 0 global mandatory_fstrim_interval ""
    settings put --user 0 global fstrim_last_trim_millis ""
    settings put --user 0 global looper_stats enabled=true,sampling_interval=1
    settings put --user 0 secure thermal_temp_state_value 1
    settings put --user 0 secure thermal_safety_mode 1
    settings put --user 0 secure game_auto_temperature 1
    settings put --user 0 global warning_temperature 1
    settings put --user 0 global thermal_limit_gpu 1
    settings put --user 0 global enable_temp_dds 1
    settings put --user 0 global battery_tip_constants app_restriction_enabled=true
    settings put --user 0 global art_verifier_verify_debuggable 0
    settings put --user 0 secure high_priority 0
    settings put --user 0 secure doze_enabled 1
    settings put --user 0 secure low_storage_check 1
    settings put --user 0 secure secure_overlay_settings 1
    settings put --user 0 global install_non_market_apps 0
    settings put --user 0 global key_high_volume 0
    settings put --user 0 global ota_disable_automatic_update 0
{

#!/system/bin/sh
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  🔄 RESTORE DEFAULT / UNINSTALLER
#  🔙 Revert to Factory Settings
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# --- Device Detection ---
BRAND=$(getprop ro.product.brand | tr '[:upper:]' '[:lower:]')
MANUFACTURER=$(getprop ro.product.manufacturer | tr '[:upper:]' '[:lower:]')
ANDROID_VER=$(getprop ro.build.version.release)

# --- Header Display (FIXED) ---
clear
echo ""
echo "♻️  SYSTEM RESTORE INITIATED"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
# Menggunakan tr untuk uppercase tampilan agar tidak error
echo "📱 Device   : $(echo $BRAND | tr 'a-z' 'A-Z') / $(echo $MANUFACTURER | tr 'a-z' 'A-Z')"
echo "🤖 Android  : $ANDROID_VER"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# ==========================================
# CORE: UNIVERSAL RESTORE
# ==========================================
restore_universal() {
    echo "🔙 Restoring Universal Settings..."
    
    # Restore Power Mode
    cmd power set-adaptive-power-saver-enabled true > /dev/null 2>&1
    cmd power set-fixed-performance-mode-enabled false > /dev/null 2>&1
    
    # Restore Touch & UX (Delete to use system default)
    settings delete --user 0 secure long_press_timeout
    settings delete --user 0 secure multi_press_timeout
    settings put --user 0 system pointer_speed 0
    settings delete --user 0 system user_experience
    
    # Restore Animation (Standard 1.0x)
    settings put --user 0 global animator_duration_scale 1.0
    settings put --user 0 global transition_animation_scale 1.0
    settings put --user 0 global window_animation_scale 1.0

    echo "✅ Universal Config Restored"
}

# ==========================================
# MODULE: PIXEL RESTORE
# ==========================================
restore_pixel() {
    echo "🧹 Cleaning Pixel Config..."
    
    settings delete --user 0 system gaming_mode_change_performance_level 
    settings delete --user 0 system gaming_mode_performance_level 
    settings delete --user 0 system gamespace_game_list 
    settings delete --user 0 system gaming_mode_enabled 
    settings delete --user 0 system gaming_mode_dynamic_add 
    settings delete --user 0 system gaming_mode_disable_auto_brightness 
    settings delete --user 0 system gaming_mode_notification_danmaku 
    settings delete --user 0 system gaming_mode_use_game_driver 
    settings delete --user 0 system gaming_mode_performance 
    settings delete --user 0 system gaming_mode_disable_notification_alert 
    settings delete --user 0 system gaming_mode_disable_ringtone 
    settings delete --user 0 system gaming_mode_auto_answer_call 
    settings delete --user 0 system gaming_mode_disable_gesture 

    echo "✅ Pixel Gaming Mode Reset"
}

# ==========================================
# MODULE: TRANSSION RESTORE
# ==========================================
restore_transsion() {
    echo "🧹 Cleaning Transsion Config..."

    setprop persist.sys.user_experience ""
    
    settings delete --user 0 system tran_settings_long_battery_auto_open_percentage
    settings delete --user 0 system power_boost_auto_open_percentage
    settings delete --user 0 global tran_settings_all_animation_scale
    settings delete --user 0 secure back_gesture_inset_scale_left
    settings delete --user 0 secure back_gesture_inset_scale_right
    settings delete --user 0 system value_vibrate_ontouch
    settings delete --user 0 system power_boost_frequency
    settings delete --user 0 system power_boost_frequency_switch
    settings delete --user 0 system tran_settings_long_battery_frequency_switch
    settings delete --user 0 system tran_cpupower_mode
    settings delete --user 0 system tran_outdoor_boost_mode
    settings delete --user 0 global os_supreme_user_experience

    # Device Config Cleanup
    for NAMESPACE in tranpm staged; do
        device_config delete $NAMESPACE com.transsion.performance.tranpm.delay_start_enable > /dev/null 2>&1
        device_config delete $NAMESPACE com.transsion.performance.tranpm.limit_start_enable > /dev/null 2>&1
        device_config delete $NAMESPACE com.transsion.performance.tranpm.preload_enable > /dev/null 2>&1
        device_config delete $NAMESPACE com.transsion.performance.tranpm.resource_manager_enable > /dev/null 2>&1
        device_config delete $NAMESPACE com.transsion.performance.tranpm.tranpm_reclaim_enable > /dev/null 2>&1
    done

    echo "✅ XOS/HiOS Settings Reset"
}

# ==========================================
# MODULE: SAMSUNG RESTORE
# ==========================================
restore_samsung() {
    echo "🧹 Cleaning Samsung Config..."
    
    settings delete --user 0 global restricted_device_performance
    settings delete --user 0 global sem_enhanced_cpu_responsiveness
    settings delete --user 0 global sem_performance_mode
    settings delete --user 0 global sem_perftune_cpugpu
    settings delete --user 0 global sem_perftune_ram
    settings delete --user 0 global sem_turbo_mode

    echo "✅ OneUI Settings Reset"
}

# ==========================================
# MODULE: XIAOMI RESTORE
# ==========================================
restore_xiaomi() {
    echo "🧹 Cleaning Xiaomi Config..."
    
    settings delete --user 0 global SUPPORT_UGD
    settings delete --user 0 global transition_animation_duration_ratio
    settings delete --user 0 secure power_supersave_tile_enabled
    settings delete --user 0 secure power_performance_tile_enabled
    settings delete --user 0 system POWER_PERFORMANCE_MODE_OPEN
    settings delete --user 0 system POWER_BALANCED_MODE_OPEN
    settings delete --user 0 system screen_game_mode
    settings delete --user 0 system perf_rt_enable
    settings delete --user 0 system perf_proc_game_List
    settings delete --user 0 global perf_hint_enable
    settings delete --user 0 secure pref_open_game_booster
    settings delete --user 0 secure speed_mode_enable
    settings delete --user 0 global DYNAMIC_PERFORMANCE_STATUS
    settings delete --user 0 global GPUTUNER_SWITCH

    echo "✅ MIUI/HyperOS Settings Reset"
}

# ==========================================
# MODULE: BBK RESTORE
# ==========================================
restore_oplus() {
    echo "🧹 Cleaning BBK Config..."
    
    settings delete --user 0 system high_performance_mode_on
    settings delete --user 0 system high_performance_mode_on_when_shutdown
    settings delete --user 0 system performance_mode_enable
    
    echo "✅ ColorOS/RealmeUI Settings Reset"
}

# ==========================================
# EXECUTION FLOW
# ==========================================

# 1. Restore Universal
restore_universal
echo ""

# 2. Restore Specific
case "$BRAND" in
    "google"|"pixel")
        restore_pixel
        ;;
    "itel"|"infinix"|"tecno")
        restore_transsion
        ;;
    "samsung")
        restore_samsung
        ;;
    "xiaomi"|"poco"|"redmi")
        restore_xiaomi
        ;;
    "oppo"|"realme"|"oneplus")
        restore_oplus
        ;;
    "vivo"|"iqoo")
        echo "🔵 Cleaning Vivo Config..."
        settings delete --user 0 global vivo_screen_refresh_rate_mode
        echo "✅ FuntouchOS Reset"
        ;;
    *)
        echo "⚠️  No specific module needed for $BRAND."
        echo "✅ Universal settings restored."
        ;;
esac

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "      🏁 FACTORY DEFAULT RESTORED       "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

    }

}
echo " "
echo " >> [ RENSHIP MODULE ] Initializing Deep Clean Protocol..."
echo " >> Detaching SYCOX Engine hooks from kernel & system..."
sleep 1

# ==========================================
# 1. RESET CORE RENDERING & GPU
# ==========================================
echo " >> [1/10] Normalizing GPU Pipeline..."

# Core GFX
setprop persist.sys.force_sw_gles ""
setprop persist.sys.composition.type ""
setprop debug.composition.type ""
setprop debug.egl.hw ""
setprop debug.egl.force_msaa ""
setprop debug.hwui.renderer ""
setprop debug.hwui.default_renderer ""
setprop debug.kill_allocating_task ""
setprop debug.performance.tuning ""
setprop debug.hwc.force_gpu ""

# Input Lag & HWC
setprop debug.hwc.fakevsync ""
setprop debug.hwc.logvsync ""
setprop debug.sf.hwc_service_name ""
setprop debug.drm.mode.force ""

# Platform specific cleanup
platform=$(getprop ro.board.platform)
if [ -n "$platform" ]; then
    setprop debug.composition."$platform".type ""
    setprop debug.sf.composition."$platform".type ""
fi

# ==========================================
# 2. RESTORE RENDERER (SKIA/VULKAN)
# ==========================================
echo " >> [2/10] Reverting Renderer Settings..."

settings delete global rendering_type
setprop debug.renderengine.backend ""
setprop debug.renderengine.vulkan ""
setprop debug.renderengine.threaded ""
setprop debug.hwui.use_gpu_pixel_buffers ""
setprop debug.hwui.use_buffer_age ""
setprop debug.hwui.app_memory_policy_size ""
setprop debug.vulkan.layers.enable ""
setprop debug.vulkan.layers.disable_all ""

# Device Configs
device_config delete core_graphics com.android.graphics.libvulkan.flags.swapchain_mutable_format_ext
device_config delete core_graphics com.android.graphics.surfaceflinger.flags.vulkan_renderengine

# ==========================================
# 3. RESET GRALLOC & QUALITY
# ==========================================
echo " >> [3/10] Cleaning up Gralloc Flags..."

setprop debug.gralloc.enable_fb_ubwc ""
setprop debug.gralloc.gfx_ubwc_disable ""
setprop debug.gralloc.map_fb_memory ""
setprop persist.sys.force_highendgfx ""
setprop debug.gfx.driver ""

# ==========================================
# 4. RESTORE TOUCH, UI & VENDOR
# ==========================================
echo " >> [4/10] Calibrating Touch & Vendor Props..."

# Animation & Sensitivity
settings delete global window_animation_scale
settings delete global transition_animation_scale
settings delete global animator_duration_scale
settings delete system pointer_speed
settings delete secure long_press_timeout
settings delete secure multi_press_timeout
settings delete secure touch_blocking_period
settings delete secure tap_duration_threshold

# Input Latency
cmd device_config delete input dispatcher_low_latency
cmd device_config delete input input_dispatch_resolution_ns
setprop debug.touch.input_boost_enabled ""
setprop debug.touch.boost ""
setprop sys.touchboost.enabled ""
setprop sys.input.resample.latency ""

# Vendor Specific (Xiaomi/Transsion Smart Touch)
setprop debug.vendor.perf.smart_touch ""
setprop debug.vendor.perf.smart_touch.move ""

# Restore Blur
setprop persist.sys.background_blur_keyguard_disabled ""
setprop persist.sys.background_blur_supported ""
setprop persist.sys.background_blur_status_default ""

# ==========================================
# 5. RESET SURFACEFLINGER & VSYNC
# ==========================================
echo " >> [5/10] Clearing VSync & Buffer Offsets..."

setprop debug.sf.max_igbp_buffers ""
setprop debug.sf.enable_gl_backpressure ""
setprop debug.sf.enable_hwc_vds ""
setprop debug.sf.predict_composition_strategy ""
setprop debug.sf.treat_170m_as_sRGB ""
setprop debug.sf.disable_client_composition_cache ""
setprop debug.sf.disable_backpressure ""
setprop debug.sf.latch_unsignaled ""

# Hapus Log Sampah
setprop debug.hwui.skia_atrace_enabled ""
setprop debug.hwui.skia_tracing_enabled ""
setprop debug.egl.checkGlError ""

# VSync Props Loop
props_list=(
  "debug.sf.early.app.duration" "debug.sf.earlyGl.app.duration"
  "debug.sf.high_fps.early.app.duration" "debug.sf.high_fps.earlyGl.app.duration"
  "debug.sf.high_fps.late.app.duration" "debug.sf.late.app.duration"
  "debug.sf.early.sf.duration" "debug.sf.earlyGl.sf.duration"
  "debug.sf.high_fps.early.sf.duration" "debug.sf.high_fps.earlyGl.sf.duration"
  "debug.sf.high_fps.late.sf.duration" "debug.sf.late.sf.duration"
  "debug.sf.earlyGl_app_phase_offset_ns" "debug.sf.early_app_phase_offset_ns"
  "debug.sf.high_fps_earlyGl_app_phase_offset_ns" "debug.sf.high_fps_early_app_phase_offset_ns"
  "debug.sf.high_fps_late_app_phase_offset_ns" "debug.sf.late_app_phase_offset_ns"
  "debug.sf.earlyGl_phase_offset_ns" "debug.sf.early_phase_offset_ns"
  "debug.sf.high_fps_earlyGl_phase_offset_ns" "debug.sf.high_fps_early_phase_offset_ns"
  "debug.sf.high_fps_late_phase_offset_ns" "debug.sf.late_phase_offset_ns"
)
for prop in "${props_list[@]}"; do setprop "$prop" ""; done

# ==========================================
# 6. RESTORE DALVIK & APP LAUNCH
# ==========================================
echo " >> [6/10] Resetting Dalvik & App Preloads..."

setprop dalvik.vm.dex2oat-threads ""
setprop dalvik.vm.boot-dex2oat-threads ""
setprop dalvik.vm.image-dex2oat-threads ""
setprop debug.hwui.render_thread_count ""
setprop debug.hwui.overdraw ""
setprop debug.hwui.show_overdraw ""

# App Launch Boosters (yang ada di bawah script asli)
setprop persist.sys.perf.topAppRenderThreadBoost.enable ""
setprop persist.sys.performance.appLaunchPreload.enable ""
setprop persist.sys.storage_preload ""

# ==========================================
# 7. ADPF & THERMAL RESTORE
# ==========================================
echo " >> [7/10] Re-enabling Thermal Monitoring..."

setprop debug.sf.enable_adpf_cpu_hint ""
setprop debug.sf.send_early_power_session_hint ""
setprop debug.sf.trace_hint_sessions ""
setprop debug.sf.normalize_hint_session_durations ""
setprop debug.sf.send_late_power_session_hint ""
setprop debug.hwui.use_hint_manager ""
setprop debug.sf.predict_hwc_composition_strategy ""
setprop debug.adpf_cts_verbose_logging ""
setprop debug.adpf.use_report_actual_duration ""

device_config delete game android.os.adpf_measure_during_input_event_boost
device_config delete game android.os.adpf_gpu_report_actual_work_duration
device_config delete game android.os.adpf_platform_power_efficiency

# ==========================================
# 8. RAM MANAGEMENT (LMK & CACHE)
# ==========================================
echo " >> [8/10] Releasing LMK & RAM Constraints..."

# Phantom Process
device_config delete activity_manager max_phantom_processes
device_config delete activity_manager boot_time_max_phantom_processes
device_config delete activity_manager max_cached_processes
device_config delete activity_manager max_empty_time_millis

# Reset Activity Settings
settings delete global always_finish_activities
cmd activity set-process-limit -1

# Reset LMKD & ZRAM
device_config delete lmkd_native thrashing_limit_critical
device_config delete lmkd_native thrashing_limit
device_config set_sync_disabled_for_tests none # Mengembalikan sync config

settings delete global zram_enabled
setprop persist.sys.zram.enabled ""
setprop sys.lmk.reportkills ""

# Reset Legacy LMK (Android 9 kebawah)
setprop sys.lmk.minfree_levels ""

# ==========================================
# 9. MEDIATEK SPECIFIC CLEANUP
# ==========================================
echo " >> [9/10] Checking MTK Specifics..."

setprop debug.mtk.powerhal.hint.bypass ""
setprop ro.vendor.mtk_fps_go_disable ""
setprop debug.mediatek.high_frame_rate_multiple_display_mode ""

# ==============================================
# UNINSTALL / REVERT: ADPF DYNAMIC LITE
# ==============================================
echo "k Mengembalikan Pengaturan ADPF ke Default (System Stock)..."

# --- 1. Disable Basic Activation ---
# Mengembalikan ke default (biasanya false pada HP Entry/Mid non-Pixel)
setprop debug.sf.enable_adpf_cpu_hint false
setprop debug.hwui.use_hint_manager false
# Trace sessions biasanya default false, tapi kita pastikan mati
setprop debug.sf.trace_hint_sessions false

# --- 2. Revert Hint Strategy ---
# Mengaktifkan kembali early hint (default sistem biasanya true/enabled)
setprop debug.sf.send_early_power_session_hint true
# Mematikan late hint (karena script install memaksanya aktif)
setprop debug.sf.send_late_power_session_hint false
# Matikan normalisasi durasi
setprop debug.sf.normalize_hint_session_durations false

# --- 3. Restore Overhead & Reporting ---
# Aktifkan kembali pelaporan durasi (penting untuk scheduler bawaan)
setprop debug.adpf.use_report_actual_duration true

# Hapus config custom agar kembali mengikuti device_config bawaan server/sistem
device_config delete game android.os.adpf_gpu_report_actual_work_duration

# Reset deviasi dan margin ke kosong (biar sistem yang menentukan defaultnya)
setprop debug.sf.allowed_actual_deviation ""
setprop debug.sf.hint_margin_us ""

# --- 4. Revert Mediatek Bypass ---
# Matikan bypass agar PowerHAL MTK bekerja secara normal
chipset=$(getprop ro.soc.manufacturer | tr '[:upper:]' '[:lower:]')
chipset2=$(getprop ro.hardware.soc.manufacturer | tr '[:upper:]' '[:lower:]')
if echo "$chipset $chipset2" | grep -qi "mediatek"; then
    setprop debug.mtk.powerhal.hint.bypass 0
fi

echo "✅ Uninstall ADPF Lite selesai. Silakan Reboot HP."

# ==========================================
# 10. FINALIZATION
# ==========================================
echo " >> [10/10] Final Cache Cleanup..."

cmd graphics_driver prercache > /dev/null 2>&1
# Reset Power Mode to Balanced (Mode 0 biasanya balanced/interactive)
cmd power set-mode 0 > /dev/null 2>&1

echo " ➤ [1/4] 🧹 Membersihkan Cache GPU..."
cmd graphics_driver prercache > /dev/null 2>&1
echo "    └─ [ ✅ OK ] GPU Cache Cleared"

echo " ➤ [2/4] 🌡️ Mengaktifkan Thermal Sensor..."
echo "    └─ [ ✅ OK ] Sensors Online"

echo " ➤ [3/4] 🗑️ Menghapus Config Game..."
echo "    └─ [ ✅ OK ] Configs Deleted"

echo " ➤ [4/4] 📱 Reset Display & Touch..."
echo "    └─ [ ✅ OK ] Touch Sensitivity Normal"

echo ""
echo "╔═══════════════════════════════════════╗"
echo "║       🛡️ LAPORAN AKHIR SYSTEM 🛡️      ║"
echo "╚═══════════════════════════════════════╝"
echo " ➤ Status Tweak    : 🔴 DEACTIVATED"
echo " ➤ Rendering       : 🤖 System Default"
echo " ➤ Power Plan      : 🔋 Balanced"
echo " ➤ Status Akhir    : ✨ PERANGKAT BERSIH"
echo "─────────────────────────────────────────"
echo ""
echo " ⚠️  REBOOT DIPERLUKAN UNTUK HASIL MAKSIMAL"

# Notifikasi Uninstal
cmd notification post -t "RENSHIP MODULE" -i "@android:drawable/stat_sys_warning" uninsttag "🗑️ SYCOX Engine Deactivated" >/dev/null 2>&1

fi
}
run
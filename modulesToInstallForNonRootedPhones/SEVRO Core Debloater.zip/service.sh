#!/system/bin/sh
setprop debug.modedcx off
#Template by DCX (@dcx400 / @dcx2123 telegram)
#modification , private use or share are allowed, no resell
#thanks @DroidEverything for the infomation and template

chipset=$(getprop ro.soc.manufacturer : | tr '[:upper:]' '[:lower:]')
chipset2=$(getprop ro.hardware.soc.manufacturer | tr '[:upper:]' '[:lower:]')
if echo "$chipset $chipset2" | grep -qi "Mediatek"; then
    # Setprop khusus Mediatek
    setprop debug.mediatek.high_frame_rate_sf_set_big_core_fps_threshold $(dumpsys display | grep -Eo 'fps=[^.]+' | cut -f2 -d= | sort -n | uniq | tail -n1)
    echo "$chipset $chipset2 Detected."
else
    echo "Non-Mediatek Detected, property skipped."
fi

# Input swipe dengan durasi lebih singkat (30ms)
input gamepad swipe 200 500 600 500 30
input touchpad swipe 200 500 300 500 30
input touchscreen swipe 100 100 500 500 10
input swipe 500 1000 900 1000 5
# Input tap
input gamepad tap 250 450
input touchpad tap 350 650
input touchscreen tap 130 180
input tap 750 1150
# Opsi eksplisit untuk memastikan respon di layar aktif
input -d 0 tap 750 1150
# Input Motion
input motionevent DOWN 200 500
input motionevent MOVE 600 500
input motionevent UP 600 500
# Input Navigation
# Swipe cepat dari kiri ke kanan (gestur "Back")
input touchnavigation swipe 30 1000 300 1000 10
# Tap area tengah bawah (seperti tombol home)
input touchnavigation tap 540 1800

setprop debug.sf.default_refresh_rate $(dumpsys display|grep -Eo 'fps=[^.]+'|cut -f2 -d=|sort -n|uniq|tail -n1)
setprop debug.sf.frame_rate_multiple_threshold $(dumpsys display|grep -Eo 'fps=[^.]+'|cut -f2 -d=|sort -n|uniq|tail -n1)
setprop debug.sf_frame_rate_multiple_fences $(dumpsys display|grep -Eo 'fps=[^.]+'|cut -f2 -d=|sort -n|uniq|tail -n1)
setprop debug.sf.touch_on_blank_not_boost_refreshrate "$(dumpsys display | grep -Eo 'fps=[0-9]+' | cut -d= -f2 | sort -n | uniq | tail -n1)"
setprop debug.sf.scroll_boost_refreshrate "$(dumpsys display | grep -Eo 'fps=[0-9]+' | cut -d= -f2 | sort -n | uniq | tail -n1)"
setprop debug.sf.touch_boost_refreshrate "$(dumpsys display | grep -Eo 'fps=[0-9]+' | cut -d= -f2 | sort -n | uniq | tail -n1)"
setprop debug.sf."$(dumpsys display | grep -Eo 'fps=[0-9]+' | cut -d= -f2 | sort -n | uniq | tail -n1)"hz_nit_lower_limit 0
setprop debug.sf.prim_perf_"$(dumpsys display | grep -Eo 'fps=[0-9]+' | cut -d= -f2 | sort -n | uniq | tail -n1)"hz_base_brightness_zone_set1 0
setprop debug.sf.prim_perf_"$(dumpsys display | grep -Eo 'fps=[0-9]+' | cut -d= -f2 | sort -n | uniq | tail -n1)"hz_base_brightness_zone 0
setprop debug.sf.prim_perf_"$(dumpsys display | grep -Eo 'fps=[0-9]+' | cut -d= -f2 | sort -n | uniq | tail -n1)"hz_base_brightness_zone 0
setprop debug.drm.mode $(echo $(wm size | awk '{print $3}') | cut -d'x' -f1)x$(echo $(wm size | awk '{print $3}') | cut -d'x' -f2)@$(dumpsys display|grep -Eo 'fps=[^.]+'|cut -f2 -d=|sort -n|uniq|tail -n1)
setprop debug.drm.mode.force $(echo $(wm size | awk '{print $3}') | cut -d'x' -f1)x$(echo $(wm size | awk '{print $3}') | cut -d'x' -f2)@$(dumpsys display|grep -Eo 'fps=[^.]+'|cut -f2 -d=|sort -n|uniq|tail -n1)
setprop debug.oculus.refreshRate $(dumpsys display|grep -Eo 'fps=[^.]+'|cut -f2 -d=|sort -n|uniq|tail -n1)
setprop debug.javafx.animation.framerate $(dumpsys display|grep -Eo 'fps=[^.]+'|cut -f2 -d=|sort -n|uniq|tail -n1)
setprop debug.redroid.fps $(dumpsys display|grep -Eo 'fps=[^.]+'|cut -f2 -d=|sort -n|uniq|tail -n1)
setprop debug.hwui.profile.maxframes $(dumpsys display|grep -Eo 'fps=[^.]+'|cut -f2 -d=|sort -n|uniq|tail -n1)
setprop debug.OVRPlugin.systemDisplayFrequency $(dumpsys display|grep -Eo 'fps=[^.]+'|cut -f2 -d=|sort -n|uniq|tail -n1)
setprop debug.refresh_rate.min_fps $(dumpsys display|grep -Eo 'fps=[^.]+'|cut -f2 -d=|sort -n|uniq|tail -n1)
setprop persist.sys.refresh_rate $(dumpsys display|grep -Eo 'fps=[^.]+'|cut -f2 -d=|sort -n|uniq|tail -n1) > /dev/null 2>&1
setprop persist.sys.NV_FPSLIMIT $(dumpsys display|grep -Eo 'fps=[^.]+'|cut -f2 -d=|sort -n|uniq|tail -n1) > /dev/null 2>&1
setprop persist.sys.fps.max $(dumpsys display|grep -Eo 'fps=[^.]+'|cut -f2 -d=|sort -n|uniq|tail -n1) > /dev/null 2>&1
setprop persist.sys.smartpower.limit.max.normal.refresh.rate.support $(dumpsys display|grep -Eo 'fps=[^.]+'|cut -f2 -d=|sort -n|uniq|tail -n1) > /dev/null 2>&1
setprop persist.sys.smartpower.limit.max.refresh.rate $(dumpsys display|grep -Eo 'fps=[^.]+'|cut -f2 -d=|sort -n|uniq|tail -n1) > /dev/null 2>&1
setprop persist.sys.sf.refresh_rate $(dumpsys display|grep -Eo 'fps=[^.]+'|cut -f2 -d=|sort -n|uniq|tail -n1) > /dev/null 2>&1
setprop sys.fps_unlock_allowed $(dumpsys display|grep -Eo 'fps=[^.]+'|cut -f2 -d=|sort -n|uniq|tail -n1) > /dev/null 2>&1
settings put system peak_refresh_rate $(dumpsys display|grep -Eo 'fps=[^.]+'|cut -f2 -d=|sort -n|uniq|tail -n1)
cmd package trim-caches 999G > /dev/null 2>&1
pm trim-caches 999G > /dev/null 2>&1
cmd shortcut reset-throttling > /dev/null 2>&1
cmd shortcut reset-all-throttling > /dev/null 2>&1

# Tweak Lainnya
setprop debug.sf.line_g3d 0
setprop debug.sf.slowmotion 0
setprop debug.sf.hdr_enable 0
setprop debug.sf.mstylus.force_on 0
setprop debug.sf.cpupolicy.vp_lp_suspend 0
setprop debug.sf.dump_re_layer 0
setprop debug.sf.fbthint 0
setprop debug.sf.kickidle.mode 1
setprop debug.sf.ovl_only_for_wifi_display 0
setprop debug.sf.rpt_fbthint 0
setprop debug.sf.skip_ext_texture 0
setprop debug.sf.validate_separate 0
setprop debug.sf.backdoor_set_display_mode_interval 0
setprop debug.sf.dump_ss 0
setprop debug.sf.log_repaint 0
setprop debug.sf.log_transaction 0
setprop debug.sf.cpupolicy.log 0

# Surface
device_config put core_graphics com.android.graphics.surfaceflinger.flags.cache_when_source_crop_layer_only_moved false
device_config put staged core_graphics*com.android.graphics.surfaceflinger.flags.cache_when_source_crop_layer_only_moved false
device_config put core_graphics com.android.graphics.surfaceflinger.flags.fp16_client_target false
device_config put staged core_graphics*com.android.graphics.surfaceflinger.flags.fp16_client_target false
device_config put core_graphics com.android.graphics.surfaceflinger.flags.enable_layer_command_batching false
device_config put staged core_graphics*com.android.graphics.surfaceflinger.flags.enable_layer_command_batching false
device_config put display_manager com.android.server.display.feature.flags.enable_get_supported_refresh_rates false
device_config put staged display_manager*com.android.server.display.feature.flags.enable_get_supported_refresh_rates false
# New HDR
device_config put core_graphics com.android.graphics.surfaceflinger.flags.connected_display_hdr false
device_config put core_graphics com.android.graphics.surfaceflinger.flags.begone_bright_hlg false
device_config put staged core_graphics*com.android.graphics.surfaceflinger.flags.connected_display_hdr false
device_config put staged core_graphics*com.android.graphics.surfaceflinger.flags.begone_bright_hlg false
device_config put core_graphics com.android.graphics.surfaceflinger.flags.stable_edid_ids true
device_config put staged core_graphics*com.android.graphics.surfaceflinger.flags.stable_edid_ids true

# ❗ Menonaktifkan sistem Frame Tracker lama agar memakai mekanisme pelacakan frame terbaru
device_config put core_graphics com.android.graphics.surfaceflinger.flags.deprecate_frame_tracker false
device_config put staged core_graphics*com.android.graphics.surfaceflinger.flags.deprecate_frame_tracker false

# ❗ Mencegah SurfaceFlinger meng-commit frame yang tidak ikut proses komposisi
device_config put core_graphics com.android.graphics.surfaceflinger.flags.commit_not_composited false
device_config put staged core_graphics*com.android.graphics.surfaceflinger.flags.commit_not_composited false

# ✅ Mengoreksi DPI berdasarkan ukuran display aktual (akurasi skala UI dan rendering meningkat)
device_config put core_graphics com.android.graphics.surfaceflinger.flags.correct_dpi_with_display_size true
device_config put staged core_graphics*com.android.graphics.surfaceflinger.flags.correct_dpi_with_display_size true

# ❗ Menonaktifkan detached mirror (tampilan mirror yang berjalan di thread terpisah)
device_config put windows_surface com.android.graphics.surfaceflinger.flags.detached_mirror false
device_config put staged windows_surface*com.android.graphics.surfaceflinger.flags.detached_mirror false

# ❗ Menonaktifkan pemeriksaan error HAL display tambahan (mengurangi overhead pengecekan)
device_config put core_graphics com.android.graphics.surfaceflinger.flags.display_config_error_hal false
device_config put staged core_graphics*com.android.graphics.surfaceflinger.flags.display_config_error_hal false

# ✅ Memfilter frame sebelum proses tracing dimulai (mengurangi log sampah, menstabilkan profiling)
device_config put core_graphics com.android.graphics.surfaceflinger.flags.filter_frames_before_trace_starts true
device_config put staged core_graphics*com.android.graphics.surfaceflinger.flags.filter_frames_before_trace_starts true

# ✅ Membersihkan buffer slot secara lebih agresif untuk mengurangi cache sampah GPU
device_config put core_graphics com.android.graphics.surfaceflinger.flags.flush_buffer_slots_to_uncache true
device_config put staged core_graphics*com.android.graphics.surfaceflinger.flags.flush_buffer_slots_to_uncache true

# ❗ Menonaktifkan override trusted overlay (mencegah perubahan overlay yang tidak perlu)
device_config put window_surfaces com.android.graphics.surfaceflinger.flags.override_trusted_overlay false
device_config put staged window_surfaces*com.android.graphics.surfaceflinger.flags.override_trusted_overlay false

# ✅ Screenshot hanya melalui satu jalur (single-hop) sehingga waktu pengambilan layar lebih cepat
device_config put windows_surface com.android.graphics.surfaceflinger.flags.single_hop_screenshot true
device_config put staged windows_surface*com.android.graphics.surfaceflinger.flags.single_hop_screenshot true

# ❗ Menonaktifkan CE Fence Promise (sinkronisasi fence tertentu) untuk mengurangi delay frame
device_config put windows_surface com.android.graphics.surfaceflinger.flags.ce_fence_promise false
device_config put staged windows_surface*com.android.graphics.surfaceflinger.flags.ce_fence_promise false
#!/system/bin/sh
# ==========================================
# ⚡ GamePulse - Smart Toggle Optimizer
# Logic: Click to Install, Click again to Uninstall
# ==========================================

# 🔒 PENANDA LOCK FILE (JANGAN DIHAPUS MANUAL)
LOCK_FILE="/data/local/tmp/gamepulse_active.lock"

# 📊 PREPARE DATA (Digunakan untuk Install & Uninstall)
ANDROID_VER=$(getprop ro.build.version.release | cut -d'.' -f1)
GAME_LIST=$(dumpsys game | grep -o "$(cmd package list packages --user 0 | cut -f2 -d:)")
if [ -z "$GAME_LIST" ]; then
    GAME_LIST=$(cmd package list packages -3 | cut -f2 -d :)
fi

# ==========================================
# 🛑 MODE: UNINSTALL (RESET)
# ==========================================
if [ -f "$LOCK_FILE" ]; then
    echo " "
    echo "╔═══════════════════════════════════════╗"
    echo "║    ♻️ GAMEPULSE: DEACTIVATING...       ║"
    echo "╚═══════════════════════════════════════╝"
    echo " "
    echo "⚙️ Mengembalikan pengaturan ke Default..."
    
    # 1. Reset Per-Game Settings
    for app in $GAME_LIST; do
        if [ "$app" = "com.frb.axmanager" ]; then continue; fi
        if [ "$app" = "android" ]; then continue; fi
        
        echo "   🔄 Reset: $app"
        
        # Hapus konfigurasi overlay
        device_config delete game_overlay "$app" > /dev/null 2>&1
        
        # Kembalikan ke Mode Standard (Balanced)
        cmd game mode standard "$app" > /dev/null 2>&1
        cmd game set --mode 0 --user 0 "$app" > /dev/null 2>&1
        
        # Reset Downscale (Jika ada)
        cmd game downscale disable "$app" > /dev/null 2>&1
    done

    # 2. Reset Global Game Driver
    echo " "
    echo "🎨 Resetting Game Driver..."
    settings delete global game_driver_opt_in_apps
    settings delete global game_driver_prerelease_opt_in_apps
    settings delete global game_driver_all_apps

    # 3. Hapus Penanda
    rm -f "$LOCK_FILE"
    
    echo " "
    echo "✅ GAMEPULSE BERHASIL DINONAKTIFKAN!"
    echo "   Device kembali ke pengaturan pabrik."

# ==========================================
# 🚀 MODE: INSTALL (OPTIMIZE)
# ==========================================
else
    # === SETTINGAN USER ===
    # Boost I/O
    BOOST_VAL="1073741824"
    # Downscale (0.9 = Tajam & Ringan)
    DS_FACTOR="0.9"
    # Mode Compile
    COMPILE_MODE="speed-profile"
    
    # Deteksi FPS Max
    MAX_FPS=$(dumpsys display | grep -Eo 'fps=[0-9]+' | sort -n | tail -n1 | cut -d= -f2)
    if [ -z "$MAX_FPS" ]; then MAX_FPS=60; fi
    MAX_FPS=${MAX_FPS%.*}

    echo " "
    echo "╔═══════════════════════════════════════╗"
    echo "║    🚀 GAMEPULSE: ACTIVATED            ║"
    echo "╠═══════════════════════════════════════╣"
    echo "║ 📱 Android Ver  : $ANDROID_VER                  ║"
    echo "║ ⚡ Target FPS   : ${MAX_FPS}Hz                ║"
    echo "║ 📉 Downscale    : ${DS_FACTOR}x                 ║"
    echo "║ 🔧 Compile Mode : $COMPILE_MODE           ║"
    echo "╚═══════════════════════════════════════╝"
    echo " "

    # Variabel Penampung List Driver
    LIST_GAME_DRIVER=""
    CNT=0

    echo "⚙️ Memulai Optimasi & Smart Compile..."

    # LOOP EKSEKUSI
    for app in $GAME_LIST; do
        if [ "$app" = "com.frb.axmanager" ]; then continue; fi
        if [ "$app" = "android" ]; then continue; fi
        if [ -z "$app" ]; then continue; fi

        CNT=$((CNT + 1))
        
        # Random Emoji
        case $((CNT % 4)) in
            0) ICON="🚀" ;;
            1) ICON="🎮" ;;
            2) ICON="🔥" ;;
            3) ICON="⚔️" ;;
        esac

        # === INTELLIGENT COMPILE CHECK ===
        DUMP_DATA=$(dumpsys package "$app" 2>/dev/null)
        SHOULD_COMPILE="yes"

        if [ "$COMPILE_MODE" != "no-compile" ]; then
            case "$COMPILE_MODE" in
                "speed-profile")
                    if echo "$DUMP_DATA" | grep -qE "=(speed-profile|speed|everything)"; then SHOULD_COMPILE="no"; fi ;;
                "speed")
                    if echo "$DUMP_DATA" | grep -qE "=(speed|everything)"; then SHOULD_COMPILE="no"; fi ;;
                "everything")
                    if echo "$DUMP_DATA" | grep -q "=everything"; then SHOULD_COMPILE="no"; fi ;;
                *)
                    if echo "$DUMP_DATA" | grep -q "=$COMPILE_MODE"; then SHOULD_COMPILE="no"; fi ;;
            esac

            if [ "$SHOULD_COMPILE" = "yes" ]; then
                cmd package compile -m "$COMPILE_MODE" -f "$app" > /dev/null 2>&1
                MSG_COMPILE="🔨 [NEW] Compiling ($COMPILE_MODE)... OK"
            else
                REAL_STATUS=$(echo "$DUMP_DATA" | grep -oE "filter=[a-z\-]+" | head -n1 | cut -d= -f2)
                if [ -z "$REAL_STATUS" ]; then REAL_STATUS="Native Optimized"; fi
                MSG_COMPILE="⚡ [ACTIVE] $REAL_STATUS"
            fi
        else
            MSG_COMPILE="💤 [OFF] Compilation Disabled"
        fi

        echo "   $ICON $app"
        echo "      └─ $MSG_COMPILE"

        # Build Driver List
        if [ -z "$LIST_GAME_DRIVER" ]; then LIST_GAME_DRIVER="$app"; else LIST_GAME_DRIVER="${LIST_GAME_DRIVER},${app}"; fi

        # Reset Config Sebelum Set
        device_config delete game_overlay "$app" > /dev/null 2>&1

        # === KONFIGURASI PERFORMA ===
        if [ "$ANDROID_VER" -ge 14 ]; then
            CONFIG_STRING="mode=2,fps=$MAX_FPS,downscaleFactor=$DS_FACTOR,loadingBoost=$BOOST_VAL,downscale=$DS_FACTOR"
            device_config put game_overlay "$app" "$CONFIG_STRING"
            cmd game mode performance "$app" > /dev/null 2>&1
            cmd game set --mode 2 --fps $MAX_FPS --downscale $DS_FACTOR --user 0 "$app" > /dev/null 2>&1

        elif [ "$ANDROID_VER" -eq 13 ]; then
            CONFIG_STRING="mode=2,fps=$MAX_FPS,downscaleFactor=$DS_FACTOR,loadingBoost=$BOOST_VAL"
            device_config put game_overlay "$app" "$CONFIG_STRING"
            cmd game mode performance "$app" > /dev/null 2>&1
            cmd game set --mode 2 --fps $MAX_FPS --downscale $DS_FACTOR --user 0 "$app" > /dev/null 2>&1

        else
            CONFIG_STRING="mode=2,fps=$MAX_FPS,loadingBoost=$BOOST_VAL"
            device_config put game_overlay "$app" "$CONFIG_STRING"
            cmd game mode performance "$app" > /dev/null 2>&1
            if [ "$DS_FACTOR" != "disable" ]; then
                cmd game downscale "$DS_FACTOR" "$app" > /dev/null 2>&1
            fi
        fi
    done

    # TERAPKAN GAME DRIVER MASSAL
    echo " "
    echo "🎨 Menerapkan Driver Grafis..."
    if [ ! -z "$LIST_GAME_DRIVER" ]; then
        settings put global game_driver_opt_in_apps "$LIST_GAME_DRIVER"
        settings put global game_driver_prerelease_opt_in_apps "$LIST_GAME_DRIVER"
        settings put global game_driver_all_apps 0
        echo "   ✅ Driver Game aktif untuk: $CNT Aplikasi"
    else
        echo "   ⚠️ Tidak ada game terdeteksi."
    fi

    # Cleanup System
    cmd looper_stats disable > /dev/null 2>&1

    # BUAT LOCK FILE (TANDA SUDAH TERPASANG)
    touch "$LOCK_FILE"

    echo " "
    echo "✅ GAMEPULSE AKTIF! $CNT Game telah dioptimalkan."
fi
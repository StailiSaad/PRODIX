#!/system/bin/sh

alias SP="setprop"
alias STS="settings"
alias C="cmd"

SP debug.performance.tuning 1
STS put global power_save_mode 0
STS put global battery_saver_enabled 0
STS put global adaptive_battery_management_enabled 0
STS put global sustained_performance_mode_enabled 1
STS put system tran_cpupower_mode 1
STS put global background_activity_starts_enabled 1
C power set-fixed-performance-mode-enabled 1
C power set-adaptive-power-saver-enabled 0
SP debug.hwui.msaa_sample_count 0
SP debug.hwui.disable_msaa true
SP debug.egl.force_msaa false
SP debug.gralloc.enable_fb_ubwc 1
STS put --user 0 global force_gpu_rendering 1
STS put --user 0 system background_power_saving_enable 0
STS put --user 0 global sys_uidcpupower 0
STS put secure screensaver_enabled 0
STS put secure screensaver_activate_on_dock 0
STS put --user 0 global display_panel_lpm false
STS put --user 0 global dynamic_power_savings 0
STS put --user 0 global dynamic_power_savings_enabled 0
STS put --user 0 global dynamic_power_savings_disable_threshold 0
STS put --user 0 global automatic_power_save_mode 0
STS put secure sysui_tuner_version 4
SP debug.sf.auto_latch_unsignaled 1
SP debug.sf.disable_backpressure 1
SP debug.sf.disable_backpressure 1
SP debug.hwui.render_dirty_regions false
DVC put surface_flinger_native_boot use_frame_rate_api true
DVC put surface_flinger_native_boot disable_backpressure true
settings put global sqlite_compatibility_wal_flags legacy_compatibility_wal_enabled=false,truncate_size=524288
settings put global sqlite_global_journal_mode WAL
settings put global sqlite_global_sync_mode NORMAL
settings put global sqlite_idle_connection_timeout 600000
settings put global sqlite_temp_store 2

activity_manager_flag=(
    "pss_collection_enabled=false"
    "activity_pss_delay_ms=9999"
    "enable_process_compaction=false"
    "enable_background_restrictions=false"
)

for flag in "${activity_manager_flag[@]}"; do
    key=$(echo "$flag" | cut -d= -f1)
    value=$(echo "$flag" | cut -d= -f2)
    DVC put activity_manager "$key" "$value"
done

set_dvc_flag() {
    DVC put "$1" "$2" "$3"
}

set_surfaceflinger_flag() {
    set_dvc_flag core_graphics "$1" "$2"
}

set_display_manager_flag() {
    set_dvc_flag display_manager "$1" "$2"
}

set_activity_manager_flag() {
    set_dvc_flag activity_manager "$1" "$2"
}

set_activity_manager_boot_flag() {
    set_dvc_flag activity_manager_native_boot "$1" "$2"
}

set_window_manager_flag() {
    set_dvc_flag window_manager "$1" "$2"
}

set_runtime_flag() {
    set_dvc_flag runtime_native "$1" "$2"
}

set_runtime_boot_flag() {
    set_dvc_flag runtime_native_boot "$1" "$2"
}

set_lmkd_flag() {
    set_dvc_flag lmkd_native "$1" "$2"
}

set_system_perf_flag() {
    set_dvc_flag system_performance "$1" "$2"
}

set_dvc_flag surface_flinger_native_boot use_frame_rate_api true
set_dvc_flag surface_flinger_native_boot skia_tracing false
set_activity_manager_flag pss_collection_enabled false
set_activity_manager_flag activity_pss_delay_ms 15000
set_activity_manager_flag enable_process_compaction false
set_activity_manager_flag enable_background_restrictions false
set_activity_manager_boot_flag modern_queue_support true
set_activity_manager_boot_flag oom_adjustment_fast true
set_window_manager_flag gesture_exclusion_debounce 0
set_window_manager_flag surface_animation_scale 0
set_runtime_flag statsd_metrics_enabled false
set_runtime_flag startup_image_cache_enabled true
set_runtime_flag background_dexopt_disabled true
set_runtime_boot_flag generational_gc_enabled true
set_runtime_boot_flag concurrent_gc_for_alloc true
set_runtime_boot_flag iorap_readahead true
set_runtime_boot_flag lock_profiling false
set_surfaceflinger_flag com.android.graphics.surfaceflinger.flags.enable_layer_caching true
set_surfaceflinger_flag com.android.graphics.surfaceflinger.flags.use_frame_rate_hysteresis false
set_surfaceflinger_flag com.android.graphics.surfaceflinger.flags.enable_small_dirty_region_opt true
set_display_manager_flag com.android.server.display.feature.flags.enable_display_refresh_rate_switching true
set_display_manager_flag com.android.server.display.feature.flags.enable_smooth_display_switching true
set_system_perf_flag android.database.sqlite.optimize_for_large_journals true
set_lmkd_flag aggressive_kill_enabled true
STS put global binder_calls_stats \
enabled=false,\
detailed_tracking=false,\
upload_data=false,\
track_calling_uid=false,\
track_screen_state=false,\
collect_latency_data=false,\
max_call_stats_count=0
STS put global appop_history_parameters \
mode=0,\
baseIntervalMillis=30000,\
intervalMultiplier=1
STS put global battery_stats_constants \
track_cpu_times_by_proc_state=false,\
track_cpu_active_cluster_time=false,\
read_binary_cpu_time=false,\
phone_on_external_stats_collection=false
STS put global battery_tip_constants \
battery_tip_enabled=false
STS put global activity_manager_constants \
full_pss_min_interval=300000,\
full_pss_lowered_interval=300000,\
memory_info_throttle_time=300000
STS put system device_idle_constants \
inactive_to=1200000,\
idle_after_inactive_to=2400000,\
idle_pending_to=1200000,\
idle_factor=3
    STS put --user 0 global activity_manager_constants \
max_cached_processes=512,\
background_settle_time=0,\
fgservice_min_shown_time=0,\
fgservice_min_report_time=0,\
fgservice_screen_on_before_time=0,\
fgservice_screen_on_after_time=0,\
gc_timeout=120000,\
gc_min_interval=120000,\
full_pss_min_interval=600000,\
full_pss_lowered_interval=600000,\
power_check_interval=60000,\
power_check_max_cpu_1=100,\
power_check_max_cpu_2=100,\
power_check_max_cpu_3=100,\
power_check_max_cpu_4=100,\
service_usage_interaction_time=0,\
usage_stats_interaction_interval=60000,\
usage_stats_interaction_interval_post_s=60000,\
service_restart_duration=1000,\
service_reset_run_duration=0,\
service_restart_duration_factor=1,\
service_min_restart_time_between=1000,\
service_max_inactivity=0,\
service_bg_start_timeout=5000,\
service_bg_activity_start_timeout=5000,\
process_start_async=true,\
content_provider_retain_time=120000,\
service_binder_callback_time=0,\
service_short_fgs_timeout=0,\
service_long_fgs_timeout=0

STS put --user 0 system activity_manager_constants \
max_cached_processes=512,\
background_settle_time=0,\
fgservice_min_shown_time=0,\
fgservice_min_report_time=0,\
fgservice_screen_on_before_time=0,\
fgservice_screen_on_after_time=0,\
gc_timeout=120000,\
gc_min_interval=120000,\
full_pss_min_interval=600000,\
full_pss_lowered_interval=600000,\
power_check_interval=60000,\
power_check_max_cpu_1=100,\
power_check_max_cpu_2=100,\
power_check_max_cpu_3=100,\
power_check_max_cpu_4=100,\
service_usage_interaction_time=0,\
usage_stats_interaction_interval=60000,\
usage_stats_interaction_interval_post_s=60000,\
service_restart_duration=1000,\
service_reset_run_duration=0,\
service_restart_duration_factor=1,\
service_min_restart_time_between=1000,\
service_max_inactivity=0,\
service_bg_start_timeout=5000,\
service_bg_activity_start_timeout=5000,\
process_start_async=true,\
content_provider_retain_time=120000,\
service_binder_callback_time=0,\
service_short_fgs_timeout=0,\
service_long_fgs_timeout=0

settings put global game_driver_preference $(getprop ro.gfx.driver.0)
settings put system game_driver_preference $(getprop ro.gfx.driver.0)
settings put global updatable_driver_all_apps 1
settings put global game_driver_all_apps 1
settings put global updatable_driver_production_opt_in_apps $(cmd package list packages --user 0 | cut -f2 -d: | paste -sd, -)
settings put global game_driver_opt_in_apps $(cmd package list packages --user 0 | cut -f2 -d: | paste -sd, -)
settings put global updatable_driver_production_allowlist $(cmd package list packages --user 0 | cut -f2 -d: | paste -sd, -)
settings delete global updatable_driver_prerelease_opt_in_apps
settings delete global game_driver_prerelease_opt_in_apps
settings delete global updatable_driver_prerelease_allowlist
settings delete global updatable_driver_production_opt_out_apps
settings delete global game_driver_opt_out_apps
settings delete global updatable_driver_production_denylist
settings delete global updatable_driver_prerelease_denylist
settings delete global game_driver_blacklists
settings delete global game_driver_whitelist
settings put global game_driver_sphal_libraries sphal_libraries
settings put global updatable_driver_sphal_libraries_filename sphal_libraries

C power set-fixed-performance-mode-enabled true
C display set-user-disabled-hdr-types 1 2 3 4
STS put --user 0 global force_gpu_rendering 1
SP debug.sf.disable_client_composition_cache 1
SP debug.hwui.use_buffer_age 1
SP debug.hwui.trace_gpu_resources false

STS put --user 0 global app_standby_enabled 0
STS put --user 0 global forced_app_standby_enabled 0
STS put --user 0 global forced_app_standby_for_small_battery_enabled 0
STS put --user 0 global force_all_apps_standby 0
STS put --user 0 global force_background_check false
STS put --user 0 global background_check_enabled false
STS put --user 0 global adaptive_battery_management_enabled 0
STS put --user 0 global app_restriction_enabled false
STS put --user 0 global cached_apps_freezer 0
STS put --user 0 global low_power 0
STS put --user 0 global low_power_sticky 0
STS put --user 0 global battery_saver_constants enabled=false
STS put --user 0 global battery_saver_mode 0
STS put --user 0 global power_save_mode_trigger 0
STS put --user 0 global restrict_background_activity 0
STS put --user 0 global background_limits_enabled false
STS put --user 0 global activity_starts_logging_enabled 0
STS put --user 0 system background_power_saving_enable 0
STS put --user 0 global low_power_trigger_level 0
STS put --user 0 global low_power_trigger_level_max 1
STS put --user 0 global app_auto_restriction_enabled 0
STS put --user 0 global dynamic_power_savings_enabled 0
STS put --user 0 global low_power_mode_suggestion_params trigger_level=1,dismiss_duration=86400000

cmd notification post -S bigtext -t '🅱️-PerfExt' '✅🔁' "successfully reinstalled"
echo "successfully reinstalled"
#!/system/bin/sh

line() {
  echo "--------------------------------------------"
}

echo
line
echo "===== DISPLAY REFRESH RATE ====="

_HZ=$(dumpsys display 2>/dev/null \
| grep -oE 'fps=[0-9]+(\.[0-9]+)?' \
| cut -d= -f2 \
| sort -nu \
| tail -n 1 \
| awk '{printf("%.0f\n", $1)}')

[ -z "$_HZ" ] && _HZ="UNKNOWN"

echo "Refresh Rate : ${_HZ} Hz"

echo
line
echo "===== SURFACEFLINGER APP DURATION (ns) ====="
echo "Early App            : $(getprop debug.sf.early.app.duration)"
echo "EarlyGl App          : $(getprop debug.sf.earlyGl.app.duration)"
echo "Late App             : $(getprop debug.sf.late.app.duration)"
echo "HFPS Early App       : $(getprop debug.sf.high_fps.early.app.duration)"
echo "HFPS EarlyGl App     : $(getprop debug.sf.high_fps.earlyGl.app.duration)"
echo "HFPS Late App        : $(getprop debug.sf.high_fps.late.app.duration)"

echo
line
echo "===== SURFACEFLINGER SF DURATION (ns) ====="
echo "Early SF             : $(getprop debug.sf.early.sf.duration)"
echo "EarlyGl SF           : $(getprop debug.sf.earlyGl.sf.duration)"
echo "Late SF              : $(getprop debug.sf.late.sf.duration)"
echo "HFPS Early SF        : $(getprop debug.sf.high_fps.early.sf.duration)"
echo "HFPS EarlyGl SF      : $(getprop debug.sf.high_fps.earlyGl.sf.duration)"
echo "HFPS Late SF         : $(getprop debug.sf.high_fps.late.sf.duration)"

echo
line
echo "===== VSYNC APP PHASE OFFSET (ns) ====="
echo "Early App Offset         : $(getprop debug.sf.early_app_phase_offset_ns)"
echo "EarlyGl App Offset       : $(getprop debug.sf.earlyGl_app_phase_offset_ns)"
echo "Late App Offset          : $(getprop debug.sf.late_app_phase_offset_ns)"
echo "HFPS Early App Offset    : $(getprop debug.sf.high_fps_early_app_phase_offset_ns)"
echo "HFPS EarlyGl App Offset  : $(getprop debug.sf.high_fps_earlyGl_app_phase_offset_ns)"
echo "HFPS Late App Offset     : $(getprop debug.sf.high_fps_late_app_phase_offset_ns)"

echo
line
echo "===== VSYNC SF PHASE OFFSET (ns) ====="
echo "Early SF Offset          : $(getprop debug.sf.early_phase_offset_ns)"
echo "EarlyGl SF Offset        : $(getprop debug.sf.earlyGl_phase_offset_ns)"
echo "Late SF Offset           : $(getprop debug.sf.late_phase_offset_ns)"
echo "HFPS Early SF Offset     : $(getprop debug.sf.high_fps_early_phase_offset_ns)"
echo "HFPS EarlyGl SF Offset   : $(getprop debug.sf.high_fps_earlyGl_phase_offset_ns)"
echo "HFPS Late SF Offset      : $(getprop debug.sf.high_fps_late_phase_offset_ns)"

line
#!/system/bin/sh

while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

alias SP="setprop"
alias STS="settings"
alias C="cmd"

STS put global enable_cellular_on_boot 1

STS put global private_dns_mode hostname
STS put global private_dns_specifier 1dot1dot1dot1.cloudflare-dns.com

SP net.dns1 1.1.1.1
SP net.dns2 1.0.0.1
SP net.dns3 9.9.9.9
SP net.dns4 8.8.8.8

C netd resolver flushdefaultif
for i in wlan0 rmnet_data0 rmnet_data1 rmnet_data2 rmnet_data3; do
  C netd resolver flushif "$i"
done

SP net.tcp.default_init_rwnd 60
SP net.ipv4.tcp_low_latency 1
SP net.ipv4.tcp_fastopen 1
SP net.ipv4.tcp_mtu_probing 1
SP net.ipv4.tcp_sack 1
SP net.ipv4.tcp_timestamps 1
SP net.ipv4.tcp_window_scaling 1
SP net.ipv4.tcp_no_metrics_save 1
SP net.ipv4.tcp_rfc1337 1
SP net.ipv4.tcp_fin_timeout 15
SP net.ipv4.tcp_keepalive_time 30
SP net.ipv4.tcp_tw_reuse 1

STS put global preferred_network_mode 11
STS put global data_roaming 0
STS put global data_activity_timeout_mobile 0
STS put global data_activity_timeout_wifi 0

C phone data enable
C phone data set-roaming disabled

STS put global network_scoring_ui_enabled 0
STS put global network_recommendations_enabled 0
STS put global network_switch_notification_daily_limit 0
STS put global network_switch_notification_rate_limit_millis 0
STS put global network_watchlist_enabled ""
STS put global network_avoid_bad_wifi 0
STS put global connectivity_metrics_buffer_size 512

STS put global wifi_verbose_logging_enabled 0
STS put global wifi_poor_connection_warning 0
STS put global wifi_wakeup_enabled 0
STS put global wifi_scan_always_enabled 0
STS put global wifi_scan_throttle_enabled 0
STS put global wifi_watchdog_poor_network_test_enabled 0
STS put global wifi_framework_scan_interval_ms 0
STS put global wifi_supplicant_scan_interval_ms 8000

C wifi set-verbose-logging disabled -l 0
C wifi force-hi-perf-mode enabled
C wifi set-connected-score 60
C wifi set-ipreach-disconnect disabled
C wifi remove-all-suggestions

for k in \
netpolicy_override_enabled \
netpolicy_quota_enabled \
netpolicy_quota_frac_jobs \
netpolicy_quota_frac_multipath \
netpolicy_quota_limited \
netpolicy_quota_unlimited \
network_metered_multipath_preference \
network_default_daily_multipath_quota_bytes; do
  STS put global "$k" 0
done

for k in \
netstats_enabled \
netstats_sample_enabled \
netstats_poll_interval \
netstats_augment_enabled \
netstats_combine_subtype_enabled; do
  STS put global "$k" 0
done

C connectivity set-chain3-enabled false

dumpsys netstats --clear
dumpsys connectivity --reset

SP net.dns_resolver.max_samples 1
SP net.dns_resolver.sample_validity_seconds 60
SP net.dns_resolver.success_threshold_percent 25

SP net.netlink.route.flush 1
SP net.netlink.route.gc_interval 10

SP net.ipv6.conf.all.disable_ipv6 0
SP net.ipv6.conf.default.accept_ra 1

STS put global network_prefetch_enabled 1
STS put global network_prediction_enabled 0
STS put global network_scoring_enabled 0
STS put global network_watchlist_enabled 0

STS put global tcp_default_init_rwnd 60
STS put global tcp_delack_min 10
STS put global tcp_delack_max 40

STS put global wifi_networks_available_repeat_delay 3000
STS put global wifi_networks_available_notification_on 0
STS put global wifi_scan_interval_ms 8000

C connectivity airplane-mode disable
C connectivity set-default-network-active true

C netpolicy set restrict-background false
C netpolicy set metered-network false

C connectivity set-multipath-preference true

C wifi force-hi-perf-mode enabled
C wifi set-poll-rssi-interval-msecs 2000

C netd resolver flushdefaultif
C netd resolver flushnet 0
C netd resolver flushnet 1

dumpsys wifi flush
dumpsys connectivity --reset
cmd notification post -S bigtext -t '🅱️-GoodPing' '📶' "Tweak successfully reinstalled" >/dev/null 2>&1
echo "successfully"
#!/system/bin/sh

line() {
  echo "------------------------------------"
}

echo
line
echo "===== DISPLAY REFRESH RATE ====="

_HZ=$(dumpsys SurfaceFlinger 2>/dev/null \
| grep -i "Active refresh rate" \
| grep -Eo '[0-9]+(\.[0-9]+)?' \
| head -n1)

[ -z "$_HZ" ] && _HZ=$(dumpsys SurfaceFlinger 2>/dev/null \
| grep -i "refresh-rate" \
| grep -Eo '[0-9]+(\.[0-9]+)?' \
| head -n1)

[ -z "$_HZ" ] && _HZ="UNKNOWN"

echo "Refresh Rate : $_HZ Hz"

echo
line
echo "===== SURFACEFLINGER APP DURATION (ns) ====="
echo "Early App        : $(getprop debug.sf.early.app.duration)"
echo "Late App         : $(getprop debug.sf.late.app.duration)"
echo "HFPS Early App   : $(getprop debug.sf.high_fps.early.app.duration)"
echo "HFPS Late App    : $(getprop debug.sf.high_fps.late.app.duration)"

echo
line
echo "===== SURFACEFLINGER SF DURATION (ns) ====="
echo "Early SF         : $(getprop debug.sf.early.sf.duration)"
echo "Late SF          : $(getprop debug.sf.late.sf.duration)"
echo "HFPS Early SF    : $(getprop debug.sf.high_fps.early.sf.duration)"
echo "HFPS Late SF     : $(getprop debug.sf.high_fps.late.sf.duration)"

echo
line
echo "===== VSYNC PHASE OFFSET (ns) ====="
echo "App Early Offset : $(getprop debug.sf.early.app.phase_offset_ns)"
echo "App Late Offset  : $(getprop debug.sf.late.app.phase_offset_ns)"
echo "HFPS App Early   : $(getprop debug.sf.high_fps.early.app.phase_offset_ns)"
echo "HFPS App Late    : $(getprop debug.sf.high_fps.late.app.phase_offset_ns)"

echo "SF Early Offset  : $(getprop debug.sf.early.sf.phase_offset_ns)"
echo "SF Late Offset   : $(getprop debug.sf.late.sf.phase_offset_ns)"
echo "HFPS SF Early    : $(getprop debug.sf.high_fps.early.sf.phase_offset_ns)"
echo "HFPS SF Late     : $(getprop debug.sf.high_fps.late.sf.phase_offset_ns)"

line